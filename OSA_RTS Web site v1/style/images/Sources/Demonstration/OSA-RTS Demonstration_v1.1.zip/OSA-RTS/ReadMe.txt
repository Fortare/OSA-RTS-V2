	Welcome to the OSA-RTS Demonstration

This installation contains the OSA-RTS Demonstration software.

The structure of this installation beheath the main OSA-RTS folder is:

	Demo							contains the main demonstration software 
	Demonstration Documentation		documents that proide installation, build and runtime instructions
	Toolset							contains the OSA-RTS executables to support the demonstartion
	

Before proceeding please read the documents in the Demonstrartion Documentation folder.