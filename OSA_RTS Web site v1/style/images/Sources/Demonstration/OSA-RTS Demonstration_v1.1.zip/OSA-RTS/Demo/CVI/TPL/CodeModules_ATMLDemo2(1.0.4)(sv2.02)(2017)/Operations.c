#include "Operations.h"

void Operation_Connect(const char* operationID, const char* signalID, char* errMsg) 
{ 
	/* Code for connecting a signal */ 
}

double Operation_Read(const char* operationID, const char* signalID, const char* measurementID, char* errMsg) 
{ 
	/* Read the signal and send its measurement */ 
	return 10; 
}

void Operation_Disconnect(const char* operationID, const char* signalID, char* errMsg) 
{ 
	/* Code for disconnecting a signal */ 
}
