﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               ACMeasure.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-ACMeasure-cs
//
// DESCRIPTION:        Implements the IACMeasure interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/ACMeasure.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 20/11/20 14:53 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using IACMeasure = TestStationDescriptionDemoV6.IACMeasure;
using ISignal = TestStationDescriptionDemoV6.ISignal;
using ISFCollection = TestStationDescriptionDemoV6.ISFCollection;
using IPhysical = TestStationDescriptionDemoV6.IPhysical;

namespace csTestStnDemoV6Imp
{
    internal class ACMeasureWithDMM1 : ACMeasure
    {
        public ACMeasureWithDMM1()
        {
            m_sUniqueId = "DMM1";

            Reporter.Report(etMsgType.eMT_IVITrace, "");

            m_sCleanup = "";

            m_ac_ampl_range = new Physical();
            m_freq = new Physical();
//			m_measurement = new Physical();
			m_measurement = m_ac_ampl_range;

            m_outSignal = new Signal();
        }
    }

    public abstract class ACMeasure : IACMeasure, IDisposable
    {
        protected String m_sUniqueId = "Unset";

        protected String m_sCleanup = "";

        protected IPhysical m_ac_ampl_range;
        protected IPhysical m_freq;
        protected IPhysical m_measurement;

        protected ISignal m_outSignal;

        #region IACMeasure Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        public ISignal Gate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public ISFCollection SignalFunctions
        {
            get { throw new NotImplementedException(); }
        }

        public ISignal Sync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IPhysical ac_ampl_range
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ACMeasure.ac_ampl_range.");
                return m_ac_ampl_range;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ACMeasure.ac_ampl_range = " + value.ToString());
                m_ac_ampl_range.value = value.value;
				m_measurement.value = value.value;
            }
        }

        public IPhysical freq
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ACMeasure.freq.");
                return m_freq;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ACMeasure.freq = " + value.ToString());
                m_freq.value = value.value;
            }
        }

        public IPhysical measurement
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ACMeasure.measurement.");
                return m_measurement;
            }
        }

        public string name
        {
            get { throw new NotImplementedException(); }
        }

        public string pinsGate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsIn
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsOut
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsSync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public ISignal get_Conn(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_In(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_Out(int at)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "ACMeasure.get_Out(" + at.ToString() + ")");
            return m_outSignal;
        }

        public object get_attribute(string name)
        {
            throw new NotImplementedException();
        }

        public void set_Conn(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        public void set_In(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "ACMeasure.Dispose()");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sCleanup);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}