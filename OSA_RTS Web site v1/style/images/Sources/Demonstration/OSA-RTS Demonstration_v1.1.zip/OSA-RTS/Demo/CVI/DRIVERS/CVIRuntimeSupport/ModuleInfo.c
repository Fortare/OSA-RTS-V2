//=================================================================================================
//
// Title:         ModuleInfo.c
// Purpose:       Implements utility functions providing information about the current module.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/ModuleInfo.c $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 14/06/12 15:04 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

// Because GetModuleDir() comes from a CVI library we use it in the only one of these functions
// where it can be used - LocnOfThisModule(). All of the others need information about module
// name as well, so for those we deconstruct information that we get from the GetModuleFileName()
// win32 call.
// Neither function is called more than once.

//=================================================================================================
// Include files

#include <ansi_c.h>

#define __ModuleInfo_C__

#include "Common.h"
#include "ModuleInfo.h"
#include "Utils.h"

#include <utility.h>

//=================================================================================================
// Static global variables

static bool gs_bFullFileSpecInfoObtained = False;

static char gs_acModuleFullPath[MAX_PATHNAME_LEN] = "";
static char gs_acModuleName[MAX_PATHNAME_LEN] = "";
static char gs_acModuleRootName[MAX_PATHNAME_LEN] = "";

//=================================================================================================
// Static function prototypes.

static void GetFullFileSpecInfo(
    void
);

//=================================================================================================
// Global functions

//=================================================================================================
const char *FullPathOfThisModule(
    void
)
{
    if (!gs_bFullFileSpecInfoObtained)
    {
        GetFullFileSpecInfo();
    }

    return gs_acModuleFullPath;
}

//=================================================================================================
const char *LocnOfThisModule(
    void
)
{
    static bool bLocnObtained = False;
    static char acModuleLocn[MAX_PATHNAME_LEN] = "";

    if (!bLocnObtained)
    {
        bool bClearBuffer = True;

        // Using __CVIUserHInst should give us the location of the 'local' module.
        int iGetModuleDirRetVal = GetModuleDir(__CVIUserHInst, acModuleLocn);
        switch (iGetModuleDirRetVal)
        {
            case 0:
                trace(TRACE_FULL, "Location of this module is '%s'.\n", acModuleLocn);
                bClearBuffer = False;
                break;
            case -1:
                trace(TRACE_ALWAYS, "Failed to obtain location of this module: "
                      "Current project has no pathname; the project is untitled.\n");
                break;
            case -2:
                trace(TRACE_ALWAYS, "Failed to obtain location of this module: "
                      "There is no current project.\n");
                break;
            case -3:
                trace(TRACE_ALWAYS, "Failed to obtain location of this module: "
                      "Out of memory.\n");
                break;
            case -4:
                trace(TRACE_ALWAYS, "Failed to obtain location of this module: "
                      "Operating system is unable to determine the module directory; "
                      "moduleHandle is probably invalid.\n");
                break;
            default:
                trace(TRACE_ALWAYS, "Failed to obtain location of this module: "
                      "Unrecognised error code (%i).\n", iGetModuleDirRetVal);
                break;
        }

        if (bClearBuffer)
        {
            acModuleLocn[0] = '\0';
        }

        bLocnObtained = True;
    }

    return acModuleLocn;
}

//=================================================================================================
const char *NameOfThisModule(
    void
)
{
    if (!gs_bFullFileSpecInfoObtained)
    {
        GetFullFileSpecInfo();
    }

    return gs_acModuleName;
}

//=================================================================================================
const char *RootNameOfThisModule(
    void
)
{
    if (!gs_bFullFileSpecInfoObtained)
    {
        GetFullFileSpecInfo();
    }

    return gs_acModuleRootName;
}

//=================================================================================================
// Static functions.

//=================================================================================================
static void GetFullFileSpecInfo(
    void
)
{
    // There's no NI library call for this, so we use a Win32 call instead.
    // But even with that we can still pass  __CVIUserHInst to get the full path of the module.
    if (GetModuleFileName(__CVIUserHInst, gs_acModuleFullPath, sizeof(gs_acModuleFullPath)) > 0)
    {
        char *pcLastBackslash = strrchr(gs_acModuleFullPath, '\\');

        snprintf(gs_acModuleName, sizeof(gs_acModuleName), "%s", pcLastBackslash + 1);
        snprintf(gs_acModuleRootName, sizeof(gs_acModuleRootName), "%s", pcLastBackslash + 1);

        char *pcLastDot = strrchr(gs_acModuleRootName, '.');

        if (pcLastDot)
        {
            *pcLastDot = '\0';
        }
    }
    else
    {
        trace(TRACE_ALWAYS, "Failed to obtained full module path. "
                            "GetLastError() returns 0x%x.\n", GetLastError());
        gs_acModuleFullPath[0] = '\0';
    }

    gs_bFullFileSpecInfoObtained = True;
}

