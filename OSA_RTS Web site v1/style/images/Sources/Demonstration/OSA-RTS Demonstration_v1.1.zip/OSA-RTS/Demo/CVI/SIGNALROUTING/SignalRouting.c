//*************************************************************************************************
//  Cassidian TES Ltd
//  � Crown Copyright 2012
//                                                                  
//  NAME:               SignalRouting.c
//                                                                      
//  SOFTWARE NUMBER:    111104/SW/OSA_RTS-SignalRouting-h
//                                                                      
//  DESCRIPTION:        Provides the functions, types and variables definitions required for the 
//                      SignalRouteing Module
//                                                                      
//  This is a controlled document. See project configuration
//  control tool for latest version and full version history.
//                                                                      
//  SCC Database:   $Archive: /OSA RTS/Demo/CVI/SIGNALROUTING/SignalRouting.c $
//  File Version:   $Revision: 1 $
//  Last Modified:  $Modtime: 18/11/20 8:59 $
//  By Author:      $Author: Knash $
//
//  $NoKeywords: $
//
//*************************************************************************************************

#define XPRESS_NOT_AVAIL true		// undefine if Teradyne Xpress Services is installed & avail
//=================================================================================================
// Include files
#include <stdtst.h>
#include <tsutil.h>
#include <ivi.h>

#ifndef XPRESS_NOT_AVAIL
#include <Teradyne_TestStudio_Xpress_Library_TestStand.h>
#endif

#include "SignalRouting.h"

//=================================================================================================
// Macros

// URI Length is indeterminate. Examples seen so far have been less than 50 characters.
#define URI_LENGTH 100
        
#define CONNECTION_PATH_LENGTH 30
        
#define PINMAP_PREFIX   "Pinmap/UUT/"
#define RECEIVER_PREFIX "Receiver/"  
        
// Error codes of interest
#define IVISWTCH_ERROR_PATH_NOT_FOUND 0xBFFA2011

//=================================================================================================
// Third party initialisation

#ifndef XPRESS_NOT_AVAIL
// Initialize TX API Exceptiong Handling
TX_INITIALIZE_EXCEPTION_HANDLING
#endif
//=================================================================================================
// Static global variables.

// Using a global variable for the remoting URI allows the IviSwtch functions 
// prototypes to be defined as per the IVI standard. Otherwise a handle to a 
// TestStand sequence context would need to be defined in the prototype.

char gs_acRemotingUri[URI_LENGTH];

//=================================================================================================
// Global functions

/*****************************************************************************
 * Function: SetRemotingUri                                                         
 * Purpose:  This function retrieves the Uniform Resource Indicator property 
 *           from the Teststand engine. The URI is used to locate the remoting 
 *           object(Xpress Services remoting Application). It is used by the 
 *           other functions in this module to access the Xpress Services API    
 *****************************************************************************/
void DLLEXPORT SetRemotingUri(CAObjHandle seqContextCVI)
{
    int error = 0;
    ErrMsg errMsg = {'\0'};
    ERRORINFO errorInfo;
    CAObjHandle engine;
#ifndef XPRESS_NOT_AVAIL
    TSObj_Property temporaryGlobals = NULL;
#endif
	char *remotingURI = NULL;

    tsErrChk(TS_SeqContextGetProperty(seqContextCVI, &errorInfo, TS_SeqContextEngine, CAVT_OBJHANDLE, &engine));
#ifndef XPRESS_NOT_AVAIL
    tsErrChk(TS_EngineGetProperty(engine, &errorInfo, TS_EngineTemporaryGlobals, CAVT_OBJHANDLE, &temporaryGlobals));
    tsErrChk(TS_PropertyGetValString(temporaryGlobals, &errorInfo, "Xpress.RemotinUri", 0, &remotingURI));

///    snprintf(gs_acRemotingUri, sizeof(gs_acRemotingUri), "%s", remotingURI);
#endif
	
	DebugPrintf("SIGNAL ROUTING:SetRemotingUri():- URI => %s\n", gs_acRemotingUri);

Error:  
    if (remotingURI != NULL)
        CA_FreeMemory(remotingURI);

#ifndef XPRESS_NOT_AVAIL
    if (error < 0)
    {
        TX_Error(errMsg);
    }
#endif
}


/*****************************************************************************
 * Function: IviSwtch_reset                                                         
 * Purpose:  This function resets the connections.                        
 *****************************************************************************/
ViStatus DLLEXPORT _VI_FUNC IviSwtch_reset(ViSession vi)
{
    return IviSwtch_DisconnectAll(vi);
}


/*****************************************************************************
 *  Function: IviSwtch_Connect
 *  Purpose:  This function connects channels 1 and 2. Xpress calculates the 
 *            shortest path between the two channels.
 *            If the connection can not be made, the function returns 
 *            - IVISWTCH_ERROR_PATH_NOT_FOUND, if the driver cannot find a 
 *              path between the two channels or the connection can not be made.
 *
 *   Xpress:  Maps to Xpress System equivalent function    
 *            TX_Connection * TX_Connect(const char * pinName1, 
 *                                       const char * pinName2);
 *           
 *****************************************************************************/
ViStatus DLLEXPORT _VI_FUNC IviSwtch_Connect(ViSession vi, ViConstString channel1,
//                                             ViConstString channel2)
											ViConstString channel2, ViConstString signal)
{
    ViStatus error = VI_SUCCESS;

    // Create pimap and receiver path arrays
    char acPinmap[CONNECTION_PATH_LENGTH];
    char acReceiver[CONNECTION_PATH_LENGTH];

    snprintf(acPinmap, sizeof(acPinmap), "%s%s", PINMAP_PREFIX, channel1);
    snprintf(acReceiver, sizeof(acReceiver), "%s%s", RECEIVER_PREFIX, channel2);

#ifndef XPRESS_NOT_AVAIL
    TX_Connection *Cnx = NULL;

    // Setup default exception handling
    TX_DECLARE_EXCEPTION_TYPE;
    TX_USE_DEFAULT_HANDLER;

    TX_TRY
    {
        // Initialize the Xpress API
        TX_InitializeEx(gs_acRemotingUri);

        Cnx = TX_ConnectPins(acPinmap, acReceiver); 
#endif
		
		DebugPrintf("SIGNAL ROUTING:IviSwtch_Connect():- %s to %s\n", acPinmap, acReceiver);

#ifndef XPRESS_NOT_AVAIL
        // Succesful if valid handle
        if (Cnx == NULL)
        {
            DebugPrintf("SIGNAL ROUTING:IviSwtch_Connect():- Failed to make connection between %s and %s\n",
                        acPinmap, acReceiver);
            error = IVISWTCH_ERROR_PATH_NOT_FOUND;
        }
    }

    TX_CATCH(e)
    {
        DebugPrintf("SIGNAL ROUTING:IviSwtch_Connect():- Exception Catch:- Failed to make connection between %s and %s\n",
                    acPinmap, acReceiver);
        error = IVISWTCH_ERROR_PATH_NOT_FOUND;
    }

    // Close the session to the TX API
    TX_TRY
    {
        TX_Close();
    }

    TX_CATCH_ANONYMOUS
    {
    }
#endif
    return error;
}

/***************************************************************************** 
 *  Function: IviSwtch_Disconnect
 *  Purpose:  This function disconnects the two channels. If no path
 *            exists between the two channels, the function returns the 
 *            IVISWTCH_ERROR_PATH_NOT_FOUND error. 
 *
 *   Xpress:  Maps to Xpress System equivalent function 
 *            TX_Connection * TX_GetConnectionHandle (const char * pinName, 
 *                                        const char * pinOrCapabilityName);
 *            void TX_Disconnect (TX_Connection * connectionHandle);
 *****************************************************************************/
ViStatus DLLEXPORT _VI_FUNC IviSwtch_Disconnect(ViSession vi, ViConstString channel1,
//                                                ViConstString channel2)
											ViConstString channel2, ViConstString signal)
{
    ViStatus error = VI_SUCCESS; 

    // Create pimap and receiver path arrays
    char acPinmap[CONNECTION_PATH_LENGTH];
    char acReceiver[CONNECTION_PATH_LENGTH];

    snprintf(acPinmap, sizeof(acPinmap), "%s%s", PINMAP_PREFIX, channel1);
    snprintf(acReceiver, sizeof(acReceiver), "%s%s", RECEIVER_PREFIX, channel2);

#ifndef XPRESS_NOT_AVAIL
    TX_Connection *Cnx = NULL;

    // Setup default exception handling
    TX_DECLARE_EXCEPTION_TYPE;
    TX_USE_DEFAULT_HANDLER;

    TX_TRY
    {
        // Initialize the Xpress API
        TX_InitializeEx(gs_acRemotingUri);
#endif
        // Disconnectthe  path defined by the two channels
        // first get the handle to the connection
        DebugPrintf("SIGNAL ROUTING:IviSwtch_Disconnect():- %s from %s\n", acPinmap, acReceiver);

#ifndef XPRESS_NOT_AVAIL
        Cnx = TX_GetConnectionHandle(acPinmap, acReceiver);

        // Succesful if valid handle
        if (Cnx != NULL)
        {
            TX_Disconnect(Cnx);
        }
        else
        {
            DebugPrintf("SIGNAL ROUTING:IviSwtch_Disconnect():- Failed to disconnect connection between %s and %s\n",
                        acPinmap, acReceiver);
            error = IVISWTCH_ERROR_PATH_NOT_FOUND;          
        }
    }

    TX_CATCH(e)
    {
        DebugPrintf("SIGNAL ROUTING:IviSwtch_Disconnect():- Exception:- Failed to disconnect connection between %s and %s\n",
                    acPinmap, acReceiver);
        error = IVISWTCH_ERROR_PATH_NOT_FOUND; 
    }

    // Close the session to the TX API
    TX_TRY
    {
        TX_Close();
    }

    TX_CATCH_ANONYMOUS
    {
    }
#endif
    return error;
}

/*****************************************************************************
 *  Function: IviSwtch_DisconnectAll
 *  Purpose:  This function disconnects all existing paths.  
 *
 *   Xpress:  Maps to Xpress System equivalent function 
 *            void TX_DisconnectAll (void);
 *****************************************************************************/
ViStatus DLLEXPORT _VI_FUNC IviSwtch_DisconnectAll(ViSession vi)
{
    ViStatus error = VI_SUCCESS; 

#ifndef XPRESS_NOT_AVAIL
    TX_Connection *Cnx = NULL;

    // Setup default exception handling
    TX_DECLARE_EXCEPTION_TYPE;
    TX_USE_DEFAULT_HANDLER;

    TX_TRY
    {
        // Initialize the Xpress API
        TX_InitializeEx(gs_acRemotingUri);
#endif
        // Disconnect all connections
        DebugPrintf("SIGNAL ROUTING:IviSwtch_DisconnectAll():- Disconnect all\n");

#ifndef XPRESS_NOT_AVAIL
        TX_DisconnectAll();
    }

    {
      DebugPrintf("SIGNAL ROUTING:IviSwtch_DisconnectAll():- Exception error:- Error occurred during call to DisconnectAll\n");
      error =  IVISWTCH_ERROR_PATH_NOT_FOUND;
    }

    // Close the session to the TX API
    TX_TRY
    {
        TX_Close();
    }
    
    TX_CATCH_ANONYMOUS
    {
    }
#endif
    return error;
}

