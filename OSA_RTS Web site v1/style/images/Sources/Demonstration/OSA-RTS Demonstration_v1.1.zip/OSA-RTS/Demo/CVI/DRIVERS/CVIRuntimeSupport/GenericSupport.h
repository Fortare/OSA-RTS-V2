//=================================================================================================
//
// Title:         GenericSupport.h
// Purpose:       Declares generic support functions common to all test stations.
//                ie. These functions can be used to exercise a total test station implementation
//                in a generic way.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/GenericSupport.h $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 6/07/12 9:50 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

#ifndef __GenericSupport_H__
#define __GenericSupport_H__

//=================================================================================================
// Include files

#include "Common.h"    // For bool

#ifdef __cplusplus
    extern "C" {
#endif

//=================================================================================================
// Types

typedef enum {eLM_Off, eLM_AutoInitOnly, eLM_Always} tLogMode;

//=================================================================================================
// Global functions

// These two functions can be used when GenericSupport isn't intialised to control log-to-file
// behaviour. They have no effect when GenericSupport is in an initialised state.

// Sets logging mode. eLM_AutoInitOnly is the default mode. It results in output being logged to
// file only when GenericSupport initialisation happens through auto-init.
void SetLogMode(
    tLogMode LogMode
);

// Sets the file to which log information is sent.
// A null string is the default value, and indicates that GenericSupport is to auto-construct
// a log file name from the name of the module of which it's a part.
void SetLogFileFullPath(
    const char *pcLogFileFullPath
);

// It's a good idea to initialise and deinitialise GenericSupport by making explicit calls to the
// following two functions.
// If an explicit call to InitialiseEverything() isn't made, auto-initialisation happens whenever
// the number of undisposed-of TSF handles is about to increment from 0, and auto-deinit happens
// whenever that number decrements to 0. If a test sequence doesn't keep a TSF handle for the
// life of the sequence, this can result in lots more init/deinits than are actually needed, hence
// it being a better idea to call these functions explicitly.

// Returns True if successful.
bool InitialiseEverything(
    void
);

void CloseEverything(
    void
);

// Frees resources associated with items obtained from other generic support functions.
// pcDescription is useful when Dispose() trace (#define TRACE_DISPOSE) is enabled in
// the GenericSupport.c implementation file and when an error occurs during disposal, but
// passing in a null string is fine if you don't care about any of that.
void Dispose(
    void        *pScalar,
    unsigned int uiTypeID,
    char        *pcDescription
);

// Returns True if successful.
// When successful, call Dispose() on pTSFInstanceHandle with uiTypeID = CDOTNET_OBJECT to release
// the TSF instance handle obtained.
bool ResMan_Require(
    const char    *pcTSFName,
    const char    *pcUniqueID,
    CDotNetHandle *pTSFInstanceHandle
);

// Returns True if successful.
// When successful, call Dispose() on pObjectPropertyHandle with uiTypeID = CDOTNET_OBJECT to
// release the object handle obtained.
bool GetObjectProperty(
    CDotNetHandle  ObjectHandle,
    const char    *pcPropertyName,
    CDotNetHandle *pObjectPropertyHandle
);

// Returns True if successful.
bool GetDoubleProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    double       *pdPropertyValue
);

// Returns True if successful.
bool GetBoolProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    bool         *pbPropertyValue
);

// Returns True if successful.
// When successful, call Dispose() on ppcPropertyValue with uiTypeID = CDOTNET_STRING to release
// the string buffer returned.
bool GetStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    char        **ppcPropertyValue
);

// Returns True if successful.
// When successful, call Dispose() on ppcPropertyValue with uiTypeID = CDOTNET_STRING to release
// the string buffer returned.
bool GetVariantStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    char        **ppcPropertyValue
);

// Returns True if successful.
bool SetStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    const char   *pcPropertyValue
);

// Returns True if successful.
bool SetVariantStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    const char   *pcPropertyValue
);

// Returns True if successful.
bool SetStaticBoolProperty(
    const char   *pcTypeName,
    const char   *pcPropertyName,
    bool          bPropertyValue
);

// Returns True if successful.
bool SetStaticStringProperty(
    const char   *pcTypeName,
    const char   *pcPropertyName,
    const char   *pcPropertyValue
);

// Returns True if successful.
bool CallMethod(
    CDotNetHandle  ObjectHandle,
    char          *pcMethodName
);

// Returns True if successful.
bool CallMethodInInt(
    CDotNetHandle  ObjectHandle,
    char          *pcMethodName,
    int            iParam
);

// Returns True if successful.
// When successful, call Dispose() on pReturnObjectHandle with uiTypeID = CDOTNET_OBJECT to
// release the object handle obtained.
bool CallMethodInIntReturnObject(
    CDotNetHandle  ObjectHandle,
    char          *pcMethodName,
    int            iParam,
    CDotNetHandle *pReturnObjectHandle
);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __GenericSupport_H__ */
