﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               ONE_DB_COMPRESSION_POINT.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-ONE_DB_COMPRESSION_POINT-cs
//
// DESCRIPTION:        Implements the IONE_DB_COMPRESSION_POINT interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/ONE_DB_COMPRESSION_POINT.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 16/06/12 23:29 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using IONE_DB_COMPRESSION_POINT = TestStationDescriptionDemoV6.IONE_DB_COMPRESSION_POINT;
using ISignal = TestStationDescriptionDemoV6.ISignal;
using ISFCollection = TestStationDescriptionDemoV6.ISFCollection;
using IPhysical = TestStationDescriptionDemoV6.IPhysical;

namespace csTestStnDemoV6Imp
{
    internal class ONE_DB_COMPRESSION_POINTWithZVB8 : ONE_DB_COMPRESSION_POINT
    {
        public ONE_DB_COMPRESSION_POINTWithZVB8()
        {
            m_sUniqueId = "ZVB8";

            Reporter.Report(etMsgType.eMT_IVITrace, "");

            m_sMeasurementCompleteFmt = "<measurement_complete> = {0}";

            m_sCleanup = "";

            m_errlmt = new Physical();
            m_input_freq = new Physical();
            m_input_pwr = new Physical();
            m_linear_gain = new Physical();
            m_measurement = new Physical();

            m_outSignal = new Signal();
        }
    }

    public abstract class ONE_DB_COMPRESSION_POINT : IONE_DB_COMPRESSION_POINT, IDisposable
    {
        protected String m_sUniqueId = "Unset";

        protected String m_sGetGOFmt = "";
        protected String m_sGetHIFmt = "";
        protected String m_sGetLOFmt = "";
        protected String m_sMeasurementCompleteFmt = "";
        protected String m_sGetuut_input_pinFmt = "";
        protected String m_sSetuut_input_pinFmt = "";
        protected String m_sGetuut_output_pinFmt = "";
        protected String m_sSetuut_output_pinFmt = "";

        protected String m_sCleanup = "";

        protected IPhysical m_errlmt;
        protected IPhysical m_input_freq;
        protected IPhysical m_input_pwr;
        protected IPhysical m_linear_gain;
        protected IPhysical m_measurement;

        protected ISignal m_outSignal;

        #region IONE_DB_COMPRESSION_POINT Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        private int m_iGoQueryCount = 0;
        public bool GO
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.GO.");
                m_iGoQueryCount = (m_iGoQueryCount + 1) % 3;

                bool bGO = (m_iGoQueryCount == 0);

                Reporter.Report(etMsgType.eMT_IVITrace, m_sGetGOFmt, (bGO ? "true" : "false"));

                return bGO;
            }
        }

        public ISignal Gate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public bool HI
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.HI.");

                bool bHI = false;

                Reporter.Report(etMsgType.eMT_IVITrace, m_sGetHIFmt, (bHI ? "true" : "false"));

                return bHI;
            }
        }

        public bool LO
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.LO.");

                bool bLO = true;

                Reporter.Report(etMsgType.eMT_IVITrace, m_sGetLOFmt, (bLO ? "true" : "false"));

                return bLO;
            }
        }

        public ISFCollection SignalFunctions
        {
            get { throw new NotImplementedException(); }
        }

        public ISignal Sync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IPhysical errlmt
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.errlmt.");
                return m_errlmt;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.errlmt = " + value.ToString());
                m_errlmt.value = value.value;
            }
        }

        public IPhysical input_freq
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.input_freq.");
                return m_input_freq;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.input_freq = " + value.ToString());
                m_input_freq.value = value.value;
            }
        }

        public IPhysical input_pwr
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.input_pwr.");
                return m_input_pwr;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.input_pwr = " + value.ToString());
                m_input_pwr.value = value.value;
            }
        }

        public IPhysical linear_gain
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.linear_gain.");
                return m_linear_gain;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.linear_gain = " + value.ToString());
                m_linear_gain.value = value.value;
            }
        }

        public IPhysical measurement
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.measurement.");
                return m_measurement;
            }
        }

        private int m_iMeasurement_completeQueryCount = 0;
        public bool measurement_complete
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.measurement_complete.");
                m_iMeasurement_completeQueryCount = (m_iMeasurement_completeQueryCount + 1) % 5;

                bool bMeasurementComplete = (m_iMeasurement_completeQueryCount == 0);

                Reporter.Report(etMsgType.eMT_IVITrace, m_sMeasurementCompleteFmt,
                                (bMeasurementComplete ? "true" : "false"));

                return bMeasurementComplete;
            }
        }

        public string name
        {
            get { throw new NotImplementedException(); }
        }

        public string pinsGate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsIn
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsOut
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsSync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        string m_uut_input_pin = "Not set";
        public string uut_input_pin
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.uut_input_pin.");
                Reporter.Report(etMsgType.eMT_IVITrace, m_sGetuut_input_pinFmt, m_uut_input_pin);
                return m_uut_input_pin;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.uut_input_pin = " + value.ToString());
                Reporter.Report(etMsgType.eMT_IVITrace, m_sSetuut_input_pinFmt, value);
                m_uut_input_pin = value;
            }
        }

        string m_uut_output_pin = "Not set";
        public string uut_output_pin
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ONE_DB_COMPRESSION_POINT.uut_output_pin.");
                Reporter.Report(etMsgType.eMT_IVITrace, m_sGetuut_output_pinFmt, m_uut_output_pin);
                return m_uut_output_pin;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.uut_output_pin = " + value.ToString());
                Reporter.Report(etMsgType.eMT_IVITrace, m_sSetuut_output_pinFmt, value);
                m_uut_output_pin = value;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public ISignal get_Conn(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_In(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_Out(int at)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.get_Out(" + at.ToString() + ")");
            return m_outSignal;
        }

        public object get_attribute(string name)
        {
            throw new NotImplementedException();
        }

        public void set_Conn(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        public void set_In(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "ONE_DB_COMPRESSION_POINT.Dispose()");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sCleanup);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
