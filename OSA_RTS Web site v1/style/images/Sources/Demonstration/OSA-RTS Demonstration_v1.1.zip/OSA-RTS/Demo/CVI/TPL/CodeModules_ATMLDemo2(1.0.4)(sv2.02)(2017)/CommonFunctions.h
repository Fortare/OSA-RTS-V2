#define   DLLEXPORT
#define ViStatus int
#define ViSession int
#define ViConstString const char *
#define _VI_FUNC

#define IviSwtch_reset(vi) void

// Switch Routing Functions
//ViStatus DLLEXPORT _VI_FUNC IviSwtch_Connect(ViSession vi, ViConstString channel1, ViConstString channel2);
#define IviSwtch_Connect(vi, channel1, channel2, signal) void
//ViStatus DLLEXPORT _VI_FUNC IviSwtch_Disconnect(ViSession vi, ViConstString channel1,ViConstString channel2);
#define IviSwtch_Disconnect(vi, channel1,channel2, signal) void
#define IviSwtch_DisconnectAll(vi) void

#define Exit_Fail(msg) (printf(msg),0)
#define Test_Log(m, l, u, s) (printf("LL:%f	UL:%f	Meas:%f%s",l,u,m,s),GONOGO=(m<l)?1:(m>u)?1:0,GONOGO) 
static int GONOGO=0;
#define UI_NOGO() (GONOGO)

