//=================================================================================================
//
// Title:         GenericSupport.c
// Purpose:       Implements generic support functions common to all test stations.
//                ie. These functions can be used to exercise a total test station implementation
//                in a generic way.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/GenericSupport.c $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 19/06/12 11:28 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

// Auto-initialisation allows everything to work without the client needing to directly call
// InitialiseEverything(). Initialisation happens automatically on the first call to
// ResMan_Require(), and clean-up code runs when the final TSF handle is disposed of.
// This gives us behaviour that's 1641-compliant (ie. there's no implementation-specific
// init/deinit calls in implementation-independent user code), at the cost of sometimes incurring
// the overhead associated with multiple init/deinit calls during execution of test programs
// which don't keep any TSFs for all test steps.

// This CVI support wrapper code currently requires user code to retain handles to TSFs until
// they've finished with any sub-objects that they may be using. There are two reasons for this:
// 1. We call the "Dispose" method on the TSF whenever Dispose() is called on a TSF handle.
// 2. Auto-initialisation deinitialises the assemblies when the final outstanding TSF handle is
//    disposed of.
// More sophisticated tracking of the relationships between, and lifetimes of, the objects
// returned by our functions would allow us to improve on both of these elements of behaviour,
// and hence remove this (non-1641) constraint.

//=================================================================================================
// Include files

#include <ansi_c.h>

#define __GenericSupport_C__

#include "Common.h"
#include "GenericSupport.h"
#include "TSFHandleListSupport.h"
#include "TestStnSpecificSupport.h"
#include "ModuleInfo.h"
#include "Utils.h"

#include <utility.h>

//=================================================================================================
// Constants

// Trace during object disposal is controlled independently with this:
//#define TRACE_DISPOSE

//=================================================================================================
// Types

struct tAssemblyAccessInfo {
    CDotNetAssemblyHandle Handle;
    bool                  bLoaded;
};

//=================================================================================================
// Static global variables

static const struct tAssemblyInfo *gs_pTypeAssemblyInfo           = NULL;
static const struct tAssemblyInfo *gs_pImplementationAssemblyInfo = NULL;

static struct tAssemblyAccessInfo gs_TypeAssemblyAccessInfo           = {0, False};
static struct tAssemblyAccessInfo gs_ImplementationAssemblyAccessInfo = {0, False};

static CDotNetHandle gs_ResManHandle;
static bool          gs_bResManHandleValid = False;

static bool          gs_bInited = False;
static bool          gs_bInitExplicit = False;

static tLogMode      gs_LogMode = eLM_AutoInitOnly;

static bool          gs_bResetLogFileOnNextInit = True;

//=================================================================================================
// Static function prototypes.

static const char *FullErrorInfo(
    int iErr
);

static bool InitialiseEverythingImplementation(
    void
);

static void AutoDetectLogFilePath(
    void
);

static void ResetLogFile(
    void
);

static bool InitialiseAssemblies(
    void
);

static void InitialiseAssembly(
    const struct tAssemblyInfo *pAssemblyInfo,
    struct tAssemblyAccessInfo *pAssemblyAccessInfo,
    const char                 *pcDescription
);

static bool RegisterAssemblyPath(
    const struct tAssemblyInfo *pAssemblyInfo,
    const char *pcDescription,
    char **ppcFullRegistrationName
);

static const char *MapAssemblyPath(
    const char *pcPath,
    const char *pcDescription
);

static void CloseAssemblies(
    void
);

static void CloseAssembly(
    const struct tAssemblyInfo *pAssemblyInfo,
    struct tAssemblyAccessInfo *pAssemblyAccessInfo,
    const char                 *pcDescription
);

static bool CreateResourceManager(
    void
);

static void ReleaseResourceManager(
    void
);

static bool GetTypeName(
    CDotNetHandle  ObjectHandle,
    char         **ppcTypeName,
    const char    *pcDescription
);

static char *GetIFTypeFromObjectType(
    const char *pcObjectTypeName
);

//=================================================================================================
// Global functions

//=================================================================================================
void SetLogMode(
    tLogMode LogMode
)
{
    if (!gs_bInited)
    {
        gs_LogMode = LogMode;
    }
    else
    {
        trace(TRACE_ALWAYS, "Ignoring call to SetLogMode() when already initialised.\n");
    }
}

//=================================================================================================
void SetLogFileFullPath(
    const char *pcLogFileFullPath
)
{
    if (!gs_bInited)
    {
        snprintf(g_acLogFileFullPath, sizeof(g_acLogFileFullPath),
                 "%s", pcLogFileFullPath);
    }
    else
    {
        trace(TRACE_ALWAYS, "Ignoring call to SetLogFileFullPath() when already initialised.\n");
    }
}

//=================================================================================================
bool InitialiseEverything(
    void
)
{
    gs_bInitExplicit = True;
    return InitialiseEverythingImplementation();
}

//=================================================================================================
void CloseEverything(
    void
)
{
    ReleaseResourceManager();
    CloseAssemblies();

    FreeTSFHandleList();

    gs_bInited = False;
    gs_bInitExplicit = False;

    trace(TRACE_BASIC, "Deinitialised.\n");

    g_bLogToFile = False;
}

//=================================================================================================
// This was originally based on something from the wrapper code produced by NI's .Net Assembly
// import tool.
// The fact it exists means that nothing else should be calling CDotNetDiscardHandle() directly.
void Dispose(
    void        *pScalar,
    unsigned int uiTypeID,
    char        *pcDescription
)
{
    if (!*(void **)pScalar)
    {
        return;
    }

    uiTypeID &= CDOTNET_BASIC_TYPE_MASK;

    if (uiTypeID == CDOTNET_STRING)
    {
        CDotNetFreeMemory(*(char **)pScalar);
        *(char **)pScalar = 0;

#ifdef TRACE_DISPOSE
        trace(TRACE_ALWAYS, "Freed memory for %s.\n", pcDescription);
#endif // TRACE_DISPOSE
    }
    else if ( (uiTypeID == CDOTNET_OBJECT) || (uiTypeID == CDOTNET_STRUCT) )
    {
        bool bIsTSF = False;

        if (uiTypeID == CDOTNET_OBJECT)
        {
            bIsTSF = RemoveFromTSFHandleList(*(CDotNetHandle *)pScalar);
        }

        if (bIsTSF)
        {
            CallMethod(*(CDotNetHandle *)pScalar, "Dispose");
        }

        int iErr = CDotNetDiscardHandle(*(CDotNetHandle *)pScalar);

        if (iErr >= 0)
        {
#ifdef TRACE_DISPOSE
            trace(TRACE_ALWAYS, "Discarded handle for %s.\n", pcDescription);
#endif // TRACE_DISPOSE
        }
        else
        {
            trace(TRACE_ALWAYS, "Failed to discard handle for %s: %s\n",
                  pcDescription,
                  FullErrorInfo(iErr));
        }

        *(CDotNetHandle *)pScalar = 0;

        if ((bIsTSF) && (GetTSFCount() < 1) && (!gs_bInitExplicit))
        {
            CloseEverything();
        }
    }
    else
    {
#ifdef TRACE_DISPOSE
        trace(TRACE_ALWAYS, "'Passive' release of %s.\n", pcDescription);
#endif // TRACE_DISPOSE
    }
}

//=================================================================================================
bool ResMan_Require(
    const char    *pcTSFName,
    const char    *pcUniqueID,
    CDotNetHandle *pTSFInstanceHandle
)
{
    trace(TRACE_FULL, "+ ResMan_Require(\"%s\", \"%s\")\n", pcTSFName, pcUniqueID);

    if (!gs_bInited)
    {
        InitialiseEverythingImplementation();
    }

    if (!gs_bResManHandleValid)
    {
        trace(TRACE_ALWAYS, "ResMan_Require(\"%s\", \"%s\") called without ResourceManager created.\n",
              pcTSFName, pcUniqueID);
        return False;
    }

    bool bAOK = False;

    CDotNetHandle UniqueIDInstanceHandle = 0;
    int iErr = CDotNetConvertValueToHandle(pcUniqueID,
                                           CDOTNET_STRING,
                                           &UniqueIDInstanceHandle);
    if (iErr >= 0)
    {
        char        *pcParameterTypeNames[2];
        unsigned int uiParameterTypes[2];
        void        *pParameters[2];

        unsigned int uiReturnValueTypeID = CDOTNET_OBJECT;

        pcParameterTypeNames[0] = "System.String";
        uiParameterTypes[0]     = (CDOTNET_STRING);
        pParameters[0]          = &pcTSFName;

        pcParameterTypeNames[1] = "System.Object";
        uiParameterTypes[1]     = (CDOTNET_OBJECT);
        pParameters[1]          = &UniqueIDInstanceHandle;

        *pTSFInstanceHandle     = 0;

        iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                          IMPLEMENTATION_ASSEMBLY_NAME ".ResourceManager",
                                          gs_ResManHandle,
                                          CDOTNET_CALL_METHOD,
                                          "Require",
                                          0, 0, 2,
                                          pcParameterTypeNames,
                                          uiParameterTypes,
                                          pParameters,
                                          &uiReturnValueTypeID,
                                          pTSFInstanceHandle,
                                          NULL);
        if (iErr >= 0)
        {
            bAOK = True;
            AddToTSFHandleList(*pTSFInstanceHandle);
        }
        else
        {
            trace(TRACE_ALWAYS, "ResMan_Require(\"%s\", \"%s\") failed: %s\n",
                  pcTSFName, pcUniqueID, FullErrorInfo(iErr));

            Dispose(pTSFInstanceHandle, CDOTNET_OBJECT,
                    "result of failed ResMan_Require()");
        }
    }
    else
    {
        trace(TRACE_ALWAYS, "ResMan_Require(\"%s\", \"%s\") failed to obtain instance handle for "
              "UniqueID parameter: %s\n",
              pcTSFName, pcUniqueID, FullErrorInfo(iErr));
    }

    Dispose(&UniqueIDInstanceHandle, CDOTNET_OBJECT,
            "UniqueID handle in ResMan_Require()");

    return bAOK;
}

//=================================================================================================
bool GetObjectProperty(
    CDotNetHandle  ObjectHandle,
    const char    *pcPropertyName,
    CDotNetHandle *pObjectPropertyHandle
)
{
    trace(TRACE_FULL, "+ GetObjectProperty(\"%s\")\n", pcPropertyName);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "GetObjectProperty() object parameter"))
    {
        unsigned int uiReturnValueTypeID = CDOTNET_OBJECT;

        *pObjectPropertyHandle = 0;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_GET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 0, 0, 0, 0,
                                              &uiReturnValueTypeID,
                                              pObjectPropertyHandle,
                                              NULL);
        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "GetObjectProperty(\"%s\") failed: %s\n",
                  pcPropertyName, FullErrorInfo(iErr));
            
            Dispose(pObjectPropertyHandle,
                    CDOTNET_OBJECT,
                    "result of failed GetObjectProperty()");
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in GetObjectProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool GetDoubleProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    double       *pdPropertyValue
)
{
    trace(TRACE_FULL, "+ GetDoubleProperty(\"%s\")\n", pcPropertyName);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "GetDoubleProperty() object parameter"))
    {
        unsigned int uiReturnValueTypeID = CDOTNET_DOUBLE;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_GET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 0, 0, 0, 0,
                                              &uiReturnValueTypeID,
                                              pdPropertyValue,
                                              NULL);

        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "GetDoubleProperty(\"%s\") failed: %s\n",
                  pcPropertyName, FullErrorInfo(iErr));
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in GetDoubleProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool GetBoolProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    bool         *pbPropertyValue
)
{
    trace(TRACE_FULL, "+ GetBoolProperty(\"%s\")\n", pcPropertyName);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "GetBoolProperty() object parameter"))
    {
        unsigned int uiReturnValueTypeID = CDOTNET_BOOLEAN;
        int iReturnValue;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_GET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 0, 0, 0, 0,
                                              &uiReturnValueTypeID,
                                              &iReturnValue,
                                              NULL);
        if (iErr >= 0)
        {
            *pbPropertyValue = ((iReturnValue != 0) ? True : False);
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "GetDoubleProperty(\"%s\") failed: %s\n",
                  pcPropertyName, FullErrorInfo(iErr));
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in GetDoubleProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool GetStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    char        **ppcPropertyValue
)
{
    trace(TRACE_FULL, "+ GetStringProperty(\"%s\")\n", pcPropertyName);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "GetStringProperty() object parameter"))
    {
        unsigned int uiReturnValueTypeID = CDOTNET_STRING;
        *ppcPropertyValue = 0;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_GET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 0, 0, 0, 0,
                                              &uiReturnValueTypeID,
                                              ppcPropertyValue,
                                              NULL);
        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "GetStringProperty(\"%s\") failed: %s\n",
                  pcPropertyName, FullErrorInfo(iErr));

            Dispose(ppcPropertyValue, CDOTNET_STRING,
                    "result of failed GetStringProperty()");
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in GetStringProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool GetVariantStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    char        **ppcPropertyValue
)
{
    trace(TRACE_FULL, "+ GetVariantStringProperty(\"%s\")\n", pcPropertyName);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "GetVariantStringProperty() object parameter"))
    {
        unsigned int uiReturnValueTypeID = CDOTNET_OBJECT;
        CDotNetHandle ReturnValueInstanceHandle = 0;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_GET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 0, 0, 0, 0,
                                              &uiReturnValueTypeID,
                                              &ReturnValueInstanceHandle,
                                              NULL);
        if (iErr >= 0)
        {
            *ppcPropertyValue = 0;

            iErr = CDotNetConvertHandleToValue(ReturnValueInstanceHandle,
                                               CDOTNET_STRING,
                                               ppcPropertyValue);
            if (iErr >= 0)
            {
                bAOK = True;
            }
            else
            {
                trace(TRACE_ALWAYS,
                      "GetVariantStringProperty(\"%s\") failed to convert value object to string: %s\n",
                      pcPropertyName, FullErrorInfo(iErr));
            }
        }
        else
        {
            trace(TRACE_ALWAYS, "GetVariantStringProperty(\"%s\") failed: %s\n",
                  pcPropertyName, FullErrorInfo(iErr));
        }

        Dispose(&ReturnValueInstanceHandle,
                CDOTNET_OBJECT,
                "value object handle in GetVariantStringProperty()");

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in GetVariantStringProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool SetStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    const char   *pcPropertyValue
)
{
    trace(TRACE_FULL, "+ SetStringProperty(\"%s\", \"%s\")\n", pcPropertyName, pcPropertyValue);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "SetStringProperty() object parameter"))
    {
        char        *pcParameterTypeNames[1];
        unsigned int uiParameterTypes[1];
        void        *pParameters[1];

        pcParameterTypeNames[0] = "System.String";
        uiParameterTypes[0]     = (CDOTNET_STRING);
        pParameters[0]          = &pcPropertyValue;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_SET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 1,
                                              pcParameterTypeNames,
                                              uiParameterTypes,
                                              pParameters,
                                              0, 0, NULL);
        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "SetStringProperty(\"%s\", \"%s\") failed: %s\n",
                  pcPropertyName, pcPropertyValue, FullErrorInfo(iErr));
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in SetStringProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool SetVariantStringProperty(
    CDotNetHandle ObjectHandle,
    const char   *pcPropertyName,
    const char   *pcPropertyValue
)
{
    trace(TRACE_FULL, "+ SetVariantStringProperty(\"%s\", \"%s\")\n", pcPropertyName, pcPropertyValue);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "SetVariantStringProperty() object parameter"))
    {
        CDotNetHandle ValueInstanceHandle = 0;
        int iErr = CDotNetConvertValueToHandle(pcPropertyValue,
                                               CDOTNET_STRING,
                                               &ValueInstanceHandle);
        if (iErr >= 0)
        {
            char        *pcParameterTypeNames[1];
            unsigned int uiParameterTypes[1];
            void        *pParameters[1];

            pcParameterTypeNames[0] = "System.Object";
            uiParameterTypes[0]     = (CDOTNET_OBJECT);
            pParameters[0]          = &ValueInstanceHandle;

            iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_SET_PROPERTY,
                                              pcPropertyName,
                                              0, 0, 1,
                                              pcParameterTypeNames,
                                              uiParameterTypes,
                                              pParameters,
                                              0, 0, NULL);
            if (iErr >= 0)
            {
                bAOK = True;
            }
            else
            {
                trace(TRACE_ALWAYS, "SetVariantStringProperty(\"%s\", \"%s\") failed: %s\n",
                      pcPropertyName, pcPropertyValue, FullErrorInfo(iErr));
            }
        }
        else
        {
            trace(TRACE_ALWAYS, "SetVariantStringProperty(\"%s\", \"%s\") failed to obtain "
                  "instance handle for value parameter: %s\n",
                  pcPropertyName, pcPropertyValue, FullErrorInfo(iErr));
        }

        Dispose(&ValueInstanceHandle, CDOTNET_OBJECT,
                "value object handle in SetVariantStringProperty()");

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in SetVariantStringProperty()");
    }

    return bAOK;
}

//=================================================================================================
bool SetStaticBoolProperty(
    const char   *pcTypeName,
    const char   *pcPropertyName,
    bool          bPropertyValue
)
{
    trace(TRACE_FULL, "+ SetStaticBoolProperty(\"%s\", \"%s\", %s)\n",
          pcTypeName, pcPropertyName, (bPropertyValue ? "True" : "False"));

    bool bAOK = False;

    char acFullTypeNameBuffer[200];
    snprintf(acFullTypeNameBuffer, sizeof(acFullTypeNameBuffer),
             "%s.%s", IMPLEMENTATION_ASSEMBLY_NAME, pcTypeName);

    char        *pcParameterTypeNames[1];
    unsigned int uiParameterTypes[1];
    void        *pParameters[1];

    int iParameterValue = (bPropertyValue ? 1 : 0);

    pcParameterTypeNames[0] = "System.Boolean";
    uiParameterTypes[0]     = (CDOTNET_BOOLEAN);
    pParameters[0]          = &iParameterValue;

    int iErr = CDotNetInvokeGenericStaticMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                                acFullTypeNameBuffer,
                                                0, 0,
                                                CDOTNET_SET_PROPERTY,
                                                pcPropertyName,
                                                0, 0,
                                                1,
                                                pcParameterTypeNames,
                                                uiParameterTypes,
                                                pParameters,
                                                0, 0, NULL);
    if (iErr >= 0)
    {
        bAOK = True;
    }
    else
    {
        trace(TRACE_ALWAYS, "SetStaticBoolProperty(\"%s\", \"%s\", %s) failed: %s\n",
              pcTypeName, pcPropertyName, (bPropertyValue ? "True" : "False"),
              FullErrorInfo(iErr));
    }

    return bAOK;
}

//=================================================================================================
bool SetStaticStringProperty(
    const char   *pcTypeName,
    const char   *pcPropertyName,
    const char   *pcPropertyValue
)
{
    trace(TRACE_FULL, "+ SetStaticStringProperty(\"%s\", \"%s\", \"%s\")\n",
          pcTypeName, pcPropertyName, pcPropertyValue);

    bool bAOK = False;

    char acFullTypeNameBuffer[200];
    snprintf(acFullTypeNameBuffer, sizeof(acFullTypeNameBuffer),
             "%s.%s", IMPLEMENTATION_ASSEMBLY_NAME, pcTypeName);

    char        *pcParameterTypeNames[1];
    unsigned int uiParameterTypes[1];
    void        *pParameters[1];

    pcParameterTypeNames[0] = "System.String";
    uiParameterTypes[0]     = (CDOTNET_STRING);
    pParameters[0]          = &pcPropertyValue;

    int iErr = CDotNetInvokeGenericStaticMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                                acFullTypeNameBuffer,
                                                0, 0,
                                                CDOTNET_SET_PROPERTY,
                                                pcPropertyName,
                                                0, 0,
                                                1,
                                                pcParameterTypeNames,
                                                uiParameterTypes,
                                                pParameters,
                                                0, 0, NULL);
    if (iErr >= 0)
    {
        bAOK = True;
    }
    else
    {
        trace(TRACE_ALWAYS, "SetStaticStringProperty(\"%s\", \"%s\", \"%s\") failed: %s\n",
              pcTypeName, pcPropertyName, pcPropertyValue, FullErrorInfo(iErr));
    }

    return bAOK;
}

//=================================================================================================
bool CallMethod(
    CDotNetHandle  ObjectHandle,
    char          *pcMethodName
)
{
    trace(TRACE_FULL, "+ CallMethod(\"%s\")\n", pcMethodName);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "CallMethodInInt() object parameter"))
    {
        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_CALL_METHOD,
                                              pcMethodName,
                                              0, 0, 0, 0, 0, 0,
                                              0, 0, NULL);
        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "CallMethod(\"%s\") failed: %s\n",
                  pcMethodName, FullErrorInfo(iErr));
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in CallMethod()");
    }

    return bAOK;
}

//=================================================================================================
bool CallMethodInInt(
    CDotNetHandle  ObjectHandle,
    char          *pcMethodName,
    int            iParam
)
{
    trace(TRACE_FULL, "+ CallMethodInInt(\"%s\", %i)\n", pcMethodName, iParam);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "CallMethodInInt() object parameter"))
    {
        char        *pcParameterTypeNames[1];
        unsigned int uiParameterTypes[1];
        void        *pParameters[1];

        pcParameterTypeNames[0] = "System.Int32";
        uiParameterTypes[0]     = (CDOTNET_INT32);
        pParameters[0]          = &iParam;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_CALL_METHOD,
                                              pcMethodName,
                                              0, 0, 1,
                                              pcParameterTypeNames,
                                              uiParameterTypes,
                                              pParameters,
                                              0, 0, NULL);
        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "CallMethodInInt(\"%s\", %i) failed: %s\n",
                  pcMethodName, iParam, FullErrorInfo(iErr));
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in CallMethodInInt()");
    }

    return bAOK;
}

//=================================================================================================
bool CallMethodInIntReturnObject(
    CDotNetHandle  ObjectHandle,
    char          *pcMethodName,
    int            iParam,
    CDotNetHandle *pReturnObjectHandle
)
{
    trace(TRACE_FULL, "+ CallMethodInIntReturnObject(\"%s\", %i)\n", pcMethodName, iParam);

    bool bAOK = False;

    char *pcTypeName = NULL;

    if (GetTypeName(ObjectHandle, &pcTypeName,
                    "CallMethodInIntReturnObject() object parameter"))
    {
        char        *pcParameterTypeNames[1];
        unsigned int uiParameterTypes[1];
        void        *pParameters[1];

        pcParameterTypeNames[0] = "System.Int32";
        uiParameterTypes[0]     = (CDOTNET_INT32);
        pParameters[0]          = &iParam;

        unsigned int uiReturnValueTypeID = CDOTNET_OBJECT;

        *pReturnObjectHandle = 0;

        int iErr = CDotNetInvokeGenericMember(gs_ImplementationAssemblyAccessInfo.Handle,
                                              pcTypeName,
                                              ObjectHandle,
                                              CDOTNET_CALL_METHOD,
                                              pcMethodName,
                                              0, 0, 1,
                                              pcParameterTypeNames,
                                              uiParameterTypes,
                                              pParameters,
                                              &uiReturnValueTypeID,
                                              pReturnObjectHandle,
                                              NULL);
        if (iErr >= 0)
        {
            bAOK = True;
        }
        else
        {
            trace(TRACE_ALWAYS, "CallMethodInIntReturnObject(\"%s\", %i) failed: %s\n",
                  pcMethodName, iParam, FullErrorInfo(iErr));
            
            Dispose(pReturnObjectHandle, CDOTNET_OBJECT,
                    "result of failed CallMethodInIntReturnObject()");
        }

        Dispose(&pcTypeName, CDOTNET_STRING,
                "object type information obtained in CallMethodInIntReturnObject()");
    }
    
    return bAOK;
}

//=================================================================================================
// Static functions.

//=================================================================================================
static const char *FullErrorInfo(
    int iErr
)
{
    static char acErrReportBuffer[300];

    const char *pcErrorDescription = CDotNetGetErrorDescription(iErr);

    // CDotNetGetErrorDescription() sometimes returns a null string first time of asking.
    if (pcErrorDescription[0] == '\0')
    {
        //trace(TRACE_ALWAYS, "(Retrying CDotNetGetErrorDescription().)\n");
        pcErrorDescription = CDotNetGetErrorDescription(iErr);
    }

    snprintf(acErrReportBuffer, sizeof(acErrReportBuffer),
             "%i - '%s'", iErr, pcErrorDescription);

    return acErrReportBuffer;
}

//=================================================================================================
static bool InitialiseEverythingImplementation(
    void
)
{
    gs_bInited = False;

    if ( (gs_LogMode == eLM_Always) ||
         ( (gs_LogMode == eLM_AutoInitOnly) && (!gs_bInitExplicit) ) )
    {
        // Enable logging (g_bLogToFile = True;) only after initialising the log file.
        if (g_acLogFileFullPath[0] == '\0')
        {
            AutoDetectLogFilePath();
        }
 
        if ( gs_bResetLogFileOnNextInit ||
             !FileExists(g_acLogFileFullPath) )
        {
            ResetLogFile();
            gs_bResetLogFileOnNextInit = False;
        }

        g_bLogToFile = True;
    }

    if (InitialiseAssemblies())
    {
        if (CreateResourceManager())
        {
            gs_bInited = True;
        }
    }

    trace(TRACE_BASIC, "Initialisation %s.\n", (gs_bInited ? "succeeded" : "failed"));

    return gs_bInited;
}

//=================================================================================================
static void AutoDetectLogFilePath(
    void
)
{
    const char *pcLocnOfThisModule = LocnOfThisModule();

    const char *pcRootNameOfThisModule = RootNameOfThisModule();

    snprintf(g_acLogFileFullPath, sizeof(g_acLogFileFullPath), "%s.TSIA.log",
             (*pcLocnOfThisModule == '\0') ? pcRootNameOfThisModule :
                                             PathCombine(pcLocnOfThisModule, pcRootNameOfThisModule) );
}

//=================================================================================================
static void ResetLogFile(
    void
)
{
    if ( (remove(g_acLogFileFullPath) == 0) ||
         (errno == ENOENT) )
    {
        FILE *pLogFileStream = fopen(g_acLogFileFullPath, "a");
        if (pLogFileStream)
        {
            fprintf(pLogFileStream, "Test Station Implementation Assembly log from module: %s\n\n",
                    FullPathOfThisModule());

            int iMonth = 1;
            int iDay = 1;
            int iYear = 2012;

            GetSystemDate(&iMonth, &iDay, &iYear);

            fprintf(pLogFileStream, "Generation Timestamp: %.2i/%.2i/%i %s\n\n",
                    iDay, iMonth, iYear, TimeStr());

            fclose(pLogFileStream);
        }
        else
        {
            trace(TRACE_ALWAYS, "Error %i opening log file for addition of header: %s\n",
                  errno, strerror(errno));
        }
    }
    else
    {
        trace(TRACE_ALWAYS, "Error %i deleting old log file: %s\n", errno, strerror(errno));
    }
}

//=================================================================================================
static bool InitialiseAssemblies(
    void
)
{
    InitAssemblyInfo(&gs_pTypeAssemblyInfo, &gs_pImplementationAssemblyInfo);

    InitialiseAssembly(gs_pTypeAssemblyInfo,
                       &gs_TypeAssemblyAccessInfo,
                       "type");

    InitialiseAssembly(gs_pImplementationAssemblyInfo,
                       &gs_ImplementationAssemblyAccessInfo,
                       "implementation");

    if (gs_ImplementationAssemblyAccessInfo.bLoaded && g_bLogToFile)
    {
        if (!SetStaticStringProperty("Config", "LogFileFullPath", g_acLogFileFullPath))
        {
            trace(TRACE_ALWAYS, "Error configuring assembly logging probably indicates that the "
                                "implementation assembly does not implement logging to file.\n");
        }
    }

    return (gs_TypeAssemblyAccessInfo.bLoaded &&
            gs_ImplementationAssemblyAccessInfo.bLoaded);
}

//=================================================================================================
static void InitialiseAssembly(
    const struct tAssemblyInfo *pAssemblyInfo,
    struct tAssemblyAccessInfo *pAssemblyAccessInfo,
    const char                 *pcDescription
)
{
    char *pcFullRegistrationName;

    if (RegisterAssemblyPath(pAssemblyInfo, pcDescription, &pcFullRegistrationName))
    {
        if (!pAssemblyAccessInfo->bLoaded)
        {
            int iErr = CDotNetLoadAssembly(pcFullRegistrationName,
                                           &(pAssemblyAccessInfo->Handle));
            if (iErr >= 0)
            {
                pAssemblyAccessInfo->bLoaded = True;

                trace(TRACE_FULL, "Loaded %s assembly %s.\n",
                                   pcDescription, pAssemblyInfo->pcName);
            }
            else
            {
                trace(TRACE_ALWAYS, "Failed to load %s assembly %s: %s\n",
                      pcDescription,
                      pAssemblyInfo->pcName,
                      FullErrorInfo(iErr));
            }
        }
        else
        {
            trace(TRACE_ALWAYS, "Ignoring attempt to initialise already initialised %s assembly %s.\n",
                  pcDescription,
                  pAssemblyInfo->pcName);
        }
    }
}

//=================================================================================================
static bool RegisterAssemblyPath(
    const struct tAssemblyInfo *pAssemblyInfo,
    const char                 *pcDescription,
    char                      **ppcFullRegistrationName
)
{
    bool bAOK = True;

    static char acDetailsBuffer[200];

    snprintf(acDetailsBuffer, sizeof(acDetailsBuffer),
             "%s, Version=%s, Culture=%s, PublicKeyToken=%s",
             pAssemblyInfo->pcName,
             pAssemblyInfo->pcVersion,
             pAssemblyInfo->pcCulture,
             pAssemblyInfo->pcPublicKeyToken);

    *ppcFullRegistrationName = acDetailsBuffer;

    const char *pcAssemblyFile = PathCombine(MapAssemblyPath(pAssemblyInfo->pcPath, pcDescription),
                                             AddExtn(pAssemblyInfo->pcName, ".dll"));

//    trace(TRACE_ALWAYS, "CDotNetRegisterAssemblyPath() params: '%s', '%s'\n",
//          acDetailsBuffer, pcAssemblyFile);

    int iErr = CDotNetRegisterAssemblyPath(acDetailsBuffer, pcAssemblyFile);

    if (iErr >= 0)
    {
        trace(TRACE_FULL, "Registered path info for %s assembly %s\n",
                          pcDescription, pAssemblyInfo->pcName);
    }
    else
    {
        bAOK = False;
        trace(TRACE_ALWAYS, "Failure registering path info for %s assembly %s: %s\n",
              pcDescription,
              pAssemblyInfo->pcName,
              FullErrorInfo(iErr));
    }

    return bAOK;
}

//=================================================================================================
// Allows us to translate assembly path information into something else.
// We use it to turn "." into an explicit statement of the location of _this_ module - be that
// dll or exe.
static const char *MapAssemblyPath(
    const char *pcPath,
    const char *pcDescription
)
{
    const char *pcRetVal = pcPath;

    if (strcmp(".", pcPath) == 0)
    {
        const char *pcLocnOfThisModule = LocnOfThisModule();

        if (*pcLocnOfThisModule != '\0')
        {
            pcRetVal = pcLocnOfThisModule;
            trace(TRACE_FULL, "Mapping %s assembly location to location of this module.\n",
                  pcDescription);
        }
    }

    return pcRetVal;
}

//=================================================================================================
static void CloseAssemblies(
    void
)
{
    CloseAssembly(gs_pTypeAssemblyInfo,
                  &gs_TypeAssemblyAccessInfo,
                  "type");

    CloseAssembly(gs_pImplementationAssemblyInfo,
                  &gs_ImplementationAssemblyAccessInfo,
                  "implementation");
}

//=================================================================================================
static void CloseAssembly(
    const struct tAssemblyInfo *pAssemblyInfo,
    struct tAssemblyAccessInfo *pAssemblyAccessInfo,
    const char                 *pcDescription
)
{
    if (pAssemblyAccessInfo->bLoaded)
    {
        int iErr = CDotNetDiscardAssemblyHandle(pAssemblyAccessInfo->Handle);

        if (iErr >= 0)
        {
            pAssemblyAccessInfo->bLoaded = False;
            trace(TRACE_FULL, "Unloaded %s assembly %s.\n",
                              pcDescription, pAssemblyInfo->pcName);
        }
        else
        {
            trace(TRACE_ALWAYS, "Failed to unload %s assembly %s: %s\n",
                  pcDescription,
                  pAssemblyInfo->pcName,
                  FullErrorInfo(iErr));
        }
    }
}

//=================================================================================================
static bool CreateResourceManager(
    void
)
{
    if (!gs_ImplementationAssemblyAccessInfo.bLoaded)
    {
        trace(TRACE_ALWAYS, "Can't create ResourceManager when implementation assembly isn't loaded.\n");
        return False;
    }

    if (gs_bResManHandleValid)
    {
        trace(TRACE_ALWAYS, "Ignoring attempt to create multiple ResourceManagers.\n");
        return True;
    }

    int iErr = CDotNetCreateGenericInstance(gs_ImplementationAssemblyAccessInfo.Handle,
                                            IMPLEMENTATION_ASSEMBLY_NAME ".ResourceManager",
                                            0, 0,
                                            &gs_ResManHandle,
                                            0, 0, 0, 0, 0);
    if (iErr >= 0)
    {
        gs_bResManHandleValid = True;
        trace(TRACE_FULL, "ResourceManager created.\n");
    }
    else
    {
        gs_bResManHandleValid = False;
        trace(TRACE_ALWAYS, "Failed to create Resource Manager: %s\n", FullErrorInfo(iErr));
    }

    return gs_bResManHandleValid;
}

//=================================================================================================
static void ReleaseResourceManager(
    void
)
{
    if (gs_bResManHandleValid)
    {
        Dispose(&gs_ResManHandle, CDOTNET_OBJECT, "ResourceManager");
        gs_bResManHandleValid = False;
    }
}

//=================================================================================================
static bool GetTypeName(
    CDotNetHandle  ObjectHandle,
    char         **ppcTypeName,
    const char    *pcDescription
)
{
    bool bAOK = False;

    int iErr = CDotNetObjectGetType(ObjectHandle,
                                    ppcTypeName,
                                    &(gs_ImplementationAssemblyAccessInfo.Handle),
                                    NULL, NULL);
    if (iErr >= 0)
    {
        bAOK = True;
        trace(TRACE_FULL, "%s type name: %s\n", pcDescription, *ppcTypeName);
    }
    else
    {
        trace(TRACE_ALWAYS, "Failed to obtain type information for %s: %s\n",
              pcDescription, FullErrorInfo(iErr));
    }

    return bAOK;
}

//=================================================================================================
// Translates an implementation object type into the corresponding type name in the type assembly.
// Currently unused, but potentially useful if we ever want to make
// CDotNetInvokeGenericInterfaceMember() calls.
static char *GetIFTypeFromObjectType(
    const char *pcObjectTypeName
)
{
    static char acIFTypeName[200];

    snprintf(acIFTypeName, sizeof(acIFTypeName), "%s", pcObjectTypeName);

    const char acExpectedObjectTypeNameStart[] = IMPLEMENTATION_ASSEMBLY_NAME ".";
    const int iExpectedObjectTypeNameStartLength = sizeof(acExpectedObjectTypeNameStart) - 1;

    if (strncmp(pcObjectTypeName,
                acExpectedObjectTypeNameStart,
                iExpectedObjectTypeNameStartLength) == 0)
    {
        snprintf(acIFTypeName, sizeof(acIFTypeName),
                 "%s.I%s",
                 TYPE_ASSEMBLY_NAME,
                 pcObjectTypeName + iExpectedObjectTypeNameStartLength);
    }

    trace(TRACE_FULL, "Translated object type '%s' to interface type '%s'.\n",
                      pcObjectTypeName, acIFTypeName);

    return acIFTypeName;
}

