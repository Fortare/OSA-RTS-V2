﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               Reporter.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-Reporter-cs
//
// DESCRIPTION:        All output and error reports go through the static Report() method
//                     implemented here in order to ensure the information goes to a log file
//                     when appropriate.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/Reporter.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 27/06/12 8:57 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace csTestStnDemoV6Imp
{
    internal enum etMsgType
    {
        eMT_Error,
        eMT_CallTrace,
        eMT_IVITrace
    }

    internal static class Reporter
    {
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Exposed Methods

        /// <summary>
        /// Reports error and trace information to the appropriate channels with the appropriate
        /// prefix, with single value substitution into a format string, as per string.format().
        /// </summary>
        /// <param name="MsgType">Class of message being reported</param>
        /// <param name="sFmtText">Message text as a format string</param>
        /// <param name="Value">Value to be embedded in sFmtText</param>
        public static void Report(etMsgType MsgType, String sFmtText, Object Value)
        {
            String sText = string.Format(sFmtText, Value);
            Report(MsgType, sText);
        }

        /// <summary>
        /// Reports error and trace information to the appropriate channels with the appropriate
        /// prefix.
        /// </summary>
        /// <param name="MsgType">Class of message being reported</param>
        /// <param name="sText">Text to be reported</param>
        public static void Report(etMsgType MsgType, String sText)
        {
            String sPrefix = Config.ErrorPrefix;

            if (MsgType == etMsgType.eMT_CallTrace)
            {
                if (!Config.CallTraceEnable)
                {
                    return;
                }
                sPrefix = Config.CallTracePrefix;
            }
            else if (MsgType == etMsgType.eMT_IVITrace)
            {
                if (!Config.IVITraceEnable)
                {
                    return;
                }
                sPrefix = Config.IVITracePrefix;
            }

            String sFullText = Prefix(sPrefix, sText);

            Console.WriteLine(sFullText);
            Trace.WriteLine(sFullText);

            if (Config.LogFileFullPath == "")
            {
                m_bLogToFileErrReported = false;
                return;
            }

            System.IO.StreamWriter fileWriteStream = null;

            try
            {
                fileWriteStream = new System.IO.StreamWriter(Config.LogFileFullPath, true);
            }
            catch (Exception exception)
            {
                if (!m_bLogToFileErrReported)
                {
                    Console.WriteLine(Prefix(Config.ErrorPrefix,
                                             "Implementation assembly unable to open log file: " + exception.Message));
                    m_bLogToFileErrReported = true;
                }
                return;
            }

            using (fileWriteStream)
            {
                try
                {
                    fileWriteStream.WriteLine(sFullText);
                }
                catch (Exception exception)
                {
                    if (!m_bLogToFileErrReported)
                    {
                        Console.WriteLine(Prefix(Config.ErrorPrefix,
                                                 "Implementation assembly unable to write to log file: " + exception.Message));
                        m_bLogToFileErrReported = true;
                    }
                    fileWriteStream.Close();
                    return;
                }

                fileWriteStream.Close();
            }

            m_bLogToFileErrReported = false;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Private Methods

        private static String Prefix(String sPrefix, String sText)
        {
            return Regex.Replace(sPrefix + sText, "\r\n", "\r\n" + sPrefix);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Implementation Data

        private static bool m_bLogToFileErrReported = false;
    }
}
