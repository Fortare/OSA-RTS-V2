//=================================================================================================
//
// Title:         TestStnSpecificSupport.h
// Purpose:       Declares support functions specific to the test station.
//                There'll need to be a man-draulically generated one of these for each total
//                test station description.
//                Look for the TAILOR_THIS tags to find the bits that need customisation.
//                Customisations in here currently make it relevant to the Demo Version 6
//                test station.
//
// Created on:    22/05/2012 at 13:38:24 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/TestStnSpecificSupport.h $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 18/06/12 10:21 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

#ifndef __TestStnSpecificSupport_H__
#define __TestStnSpecificSupport_H__

#ifdef __cplusplus
    extern "C" {
#endif

//=================================================================================================
// Types

// TAILOR_THIS
#define TYPE_ASSEMBLY_NAME           "TestStationDescriptionDemoV6"
#define IMPLEMENTATION_ASSEMBLY_NAME "csTestStnDemoV6Imp"

// These rely on CVI's .Net assembly wrappers having been generated.
// They're useful for refering to assembly-defined enums in a non-assembly-specifc way.
// TAILOR_THIS
#define PREFIX_WITH_TYPE_ASS_NAME(a) TestStationDescriptionDemoV6##a
#define PREFIX_WITH_IMP_ASS_NAME(a)  csTestStnDemoV6Imp##a

struct tAssemblyInfo {
    const char *pcName;
    const char *pcVersion;
    const char *pcCulture;
    const char *pcPublicKeyToken;
    const char *pcPath;
};

//=================================================================================================
// Global functions

void InitAssemblyInfo(
    const struct tAssemblyInfo ** const ppTypeAssemblyInfo,
    const struct tAssemblyInfo ** const ppImplementationAssemblyInfo
);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __TestStnSpecificSupport_H__ */
