//=================================================================================================
//
// Title:         Common.h
// Purpose:       Definitions common to all files in the project.
//
// Created on:    22/05/2012 at 12:56:00 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/Common.h $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 6/07/12 9:51 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

#ifndef __Common_H__
#define __Common_H__

#include <cvidef.h>
#include <cvidotnet.h>

#ifdef __cplusplus
    extern "C" {
#endif

typedef enum {False = 0, True = 1} bool;

#ifdef __cplusplus
    }
#endif // def __cplusplus

#endif /* ndef __Common_H__ */
