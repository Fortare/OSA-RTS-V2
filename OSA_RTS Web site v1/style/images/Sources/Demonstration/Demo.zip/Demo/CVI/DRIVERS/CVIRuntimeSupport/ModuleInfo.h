//=================================================================================================
//
// Title:         ModuleInfo.h
// Purpose:       Declares utility functions providing information about the current module.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/ModuleInfo.h $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 14/06/12 14:54 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

#ifndef __ModuleInfo_H__
#define __ModuleInfo_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Global functions

const char *FullPathOfThisModule(
    void
);

const char *LocnOfThisModule(
    void
);

const char *NameOfThisModule(
    void
);

const char *RootNameOfThisModule(
    void
);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __ModuleInfo_H__ */
