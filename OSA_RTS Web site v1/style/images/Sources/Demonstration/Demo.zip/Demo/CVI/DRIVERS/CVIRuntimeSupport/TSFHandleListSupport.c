//=================================================================================================
//
// Title:         TSFHandleListSupport.c
// Purpose:       Implements a linked list of TSF object handles, behind a suitably abstracted
//                interface.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/TSFHandleListSupport.c $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 14/06/12 13:11 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

//=================================================================================================
// Include files

#include <ansi_c.h>

#define __TSFHandleListSupport_C__

#include "Common.h"
#include "TSFHandleListSupport.h"

//=================================================================================================
// Types

struct tTSFHandleListItem {
    CDotNetHandle              Handle;
    struct tTSFHandleListItem *pNext;
};

//=================================================================================================
// Static global variables

static int gs_iTSFCount = 0;

static struct tTSFHandleListItem *gs_pHandleListHead = NULL;

//=================================================================================================
// Global functions

//=================================================================================================
void AddToTSFHandleList(
    CDotNetHandle TSFInstanceHandle
)
{
    struct tTSFHandleListItem *pNewListItem =
        (struct tTSFHandleListItem *)malloc(sizeof(struct tTSFHandleListItem));

    if (pNewListItem == NULL)
    {
        printf("malloc() failure tracking TSF handles for reference counting.\n");
        return;
    }

    pNewListItem->Handle = TSFInstanceHandle;
    pNewListItem->pNext = gs_pHandleListHead;

    gs_pHandleListHead = pNewListItem;
    gs_iTSFCount++;
}

//=================================================================================================
// Return value flags whether or not TSFInstanceHandle was present in the list. ie. Whether or not
// the supplied handle relates to a TSF.
bool RemoveFromTSFHandleList(
    CDotNetHandle TSFInstanceHandle
)
{
    bool bRetVal = False;

    struct tTSFHandleListItem **ppCompareItem = &gs_pHandleListHead;

    while ( (!bRetVal) && (*ppCompareItem) )
    {
        if ((*ppCompareItem)->Handle == TSFInstanceHandle)
        {
            struct tTSFHandleListItem *pNewNext = (*ppCompareItem)->pNext;
            free(*ppCompareItem);
            *ppCompareItem = pNewNext;
            gs_iTSFCount--;
            bRetVal = True;
        }
        else
        {
            ppCompareItem = &((*ppCompareItem)->pNext);
        }
    }

    return bRetVal;
}

//=================================================================================================
int GetTSFCount(
    void
)
{
    return gs_iTSFCount;
}

//=================================================================================================
void FreeTSFHandleList(
    void
)
{
    struct tTSFHandleListItem *pItem = gs_pHandleListHead;

    while (pItem)
    {
        struct tTSFHandleListItem *pNext = pItem->pNext;
        free(pItem);
        pItem = pNext;
    }

    gs_pHandleListHead = NULL;
    gs_iTSFCount = 0;
}
