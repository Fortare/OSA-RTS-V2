//=================================================================================================
//
// Title:         TSFHandleListSupport.h
// Purpose:       Declares a suitably abstracted interface for accessing the list of handles to
//                'live' TSFs.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/TSFHandleListSupport.h $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 6/07/12 9:44 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

#ifndef __TSFHandleListSupport_H__
#define __TSFHandleListSupport_H__

//=================================================================================================
// Include files

#include "Common.h"    // For bool

#ifdef __cplusplus
    extern "C" {
#endif

//=================================================================================================
// Global functions

// Adds TSFInstanceHandle to the list of 'live' TSF handles.
void AddToTSFHandleList(
    CDotNetHandle TSFInstanceHandle
);

// Removes TSFInstanceHandle from the list of 'live' TSF handles, if it's present.
// Returns True if it was present and False if it wasn't, hence indicating whether or not the
// handle supplied related to a TSF.
bool RemoveFromTSFHandleList(
    CDotNetHandle TSFInstanceHandle
);

// Returns the number of TSF handles in the list.
int GetTSFCount(
    void
);

// Empties the list.
void FreeTSFHandleList(
    void
);

#ifdef __cplusplus
    }
#endif

#endif // ndef __TSFHandleListSupport_H__
