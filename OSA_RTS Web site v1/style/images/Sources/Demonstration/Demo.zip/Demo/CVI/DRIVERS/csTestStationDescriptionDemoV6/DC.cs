﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               DC.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-DC-cs
//
// DESCRIPTION:        Implements the IDC interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/DC.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 18/06/12 15:05 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using IDC = TestStationDescriptionDemoV6.IDC;
using ISignal = TestStationDescriptionDemoV6.ISignal;
using ISFCollection = TestStationDescriptionDemoV6.ISFCollection;
using IPhysical = TestStationDescriptionDemoV6.IPhysical;

namespace csTestStnDemoV6Imp
{
    internal class DCWithDCPS1 : DC
    {
        public DCWithDCPS1()
        {
            m_sUniqueId = "DCPS1";

            Reporter.Report(etMsgType.eMT_IVITrace, "IviDCPwr_init(\"DCPS1\", VI_FALSE, VI_FALSE, &m_dcps);\r\n" +
                                                    "IviDCPwr_GetChannelName(m_dcps, 2, 256, dcpsChName);  // DCPS ch #2 is used on the PXI system\r\n" +
                                                    "IviDCPwr_ConfigureOutputEnabled(m_dcps, dcpsChName, VI_FALSE);\r\n" +
                                                    "// Delay for 0.5 seconds to trigger firmware reboot.\r\n" +
                                                    "Delay(0.5);");

            m_sCleanup = "IviDCPwr_close(m_dcps);";

            m_dc_ampl = new Physical_DCWithDCPS1_dc_ampl();

            m_outSignal = new SignalDCWithDCPS1_outSignal();
        }
    }

    public abstract class DC : IDC, IDisposable
    {
        protected String m_sUniqueId = "Unset";

        protected String m_sCleanup = "";

        protected IPhysical m_dc_ampl;

        protected ISignal m_outSignal;

        #region IDC Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        public ISignal Gate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public ISFCollection SignalFunctions
        {
            get { throw new NotImplementedException(); }
        }

        public ISignal Sync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IPhysical dc_ampl
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying DC.dc_ampl.");
                return m_dc_ampl;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "DC.dc_ampl = " + value.ToString());
                m_dc_ampl.value = value.value;
            }
        }

        public string name
        {
            get { throw new NotImplementedException(); }
        }

        public string pinsGate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsIn
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsOut
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsSync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public ISignal get_Conn(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_In(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_Out(int at)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "DC.get_Out(" + at.ToString() + ")");
            return m_outSignal;
        }

        public object get_attribute(string name)
        {
            throw new NotImplementedException();
        }

        public void set_Conn(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        public void set_In(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "DC.Dispose()");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sCleanup);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
