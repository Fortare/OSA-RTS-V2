﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               MeasureResistance.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-MeasureResistance-cs
//
// DESCRIPTION:        Implements the IMeasureResistance interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/MeasureResistance.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 20/11/20 14:41 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using IMeasureResistance = TestStationDescriptionDemoV6.IMeasureResistance;
using ISignal = TestStationDescriptionDemoV6.ISignal;
using ISFCollection = TestStationDescriptionDemoV6.ISFCollection;
using IPhysical = TestStationDescriptionDemoV6.IPhysical;

namespace csTestStnDemoV6Imp
{
    internal class MeasureResistanceWithDMM1 : MeasureResistance
    {
        public MeasureResistanceWithDMM1()
        {
            m_sUniqueId = "DMM1";

            Reporter.Report(etMsgType.eMT_IVITrace, "IviDmm_init(\"DMM1\", VI_TRUE, VI_TRUE, &m_dmm);\r\n" +
                                                    "IviDmm_SetAttributeViInt32(m_dmm, VI_NULL, IVIDMM_ATTR_FUNCTION, IVIDMM_VAL_2_WIRE_RES);");

            m_sCleanup = "IviDmm_reset(m_dmm);\r\n" +
                         "IviDmm_close(m_dmm);";

            m_nominal = new Physical_MeasureResistanceWithDMM1_nominal();
//			m_measurement = new Physical_MeasureResistanceWithDMM1_measurement();
			m_measurement = m_nominal;

            m_outSignal = new Signal();
        }
    }

    public abstract class MeasureResistance : IMeasureResistance, IDisposable
    {
        protected String m_sUniqueId = "Unset";

        protected String m_sCleanup = "";

        protected IPhysical m_nominal;
        protected IPhysical m_measurement;

        protected ISignal m_outSignal;

        #region IMeasureResistance Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        public ISignal Gate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public ISFCollection SignalFunctions
        {
            get { throw new NotImplementedException(); }
        }

        public ISignal Sync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string name
        {
            get { throw new NotImplementedException(); }
        }

        public IPhysical nominal
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying MeasureResistance.nominal.");
                return m_nominal;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "MeasureResistance.nominal = " + value.ToString());
                m_nominal.value = value.value;
            }
        }

        public string pinsGate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsIn
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsOut
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsSync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IPhysical measurement
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying MeasureResistance.measurement.");
                return m_measurement;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public ISignal get_Conn(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_In(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_Out(int at)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "MeasureResistance.get_Out(" + at.ToString() + ")");
            return m_outSignal;
        }

        public object get_attribute(string name)
        {
            throw new NotImplementedException();
        }

        public void set_Conn(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        public void set_In(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "MeasureResistance.Dispose()");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sCleanup);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
