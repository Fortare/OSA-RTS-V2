//=================================================================================================
//
// Title:         Utils.c
// Purpose:       Implements useful general purpose utility functions.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/Utils.c $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 27/06/12 10:12 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

//=================================================================================================
// Include files

#include <ansi_c.h>

#define __Utils_C__

#include "Common.h"
#include "Utils.h"

#include <formatio.h>

//=================================================================================================
// Constants

// Trace messages with a level above TRACE_LEVEL don't get reported.
#define TRACE_LEVEL TRACE_OFF

//=================================================================================================
// Global functions

//=================================================================================================
void trace(
    int         iMessageLevel,
    const char *pcFormatString,
    ...
)
{
    if (iMessageLevel <= TRACE_LEVEL)
    {
        // We're using two va_lists here so that we don't have to impose a limit on how long a
        // trace message can be.

        va_list ParamListForStdOut;
        va_start(ParamListForStdOut, pcFormatString);
        int iFormattedStringLength = vprintf(pcFormatString, ParamListForStdOut);
        va_end(ParamListForStdOut);

        if (iFormattedStringLength > 0)
        {
            char acFormattedString[iFormattedStringLength + 1];

            va_list ParamListForString;
            va_start(ParamListForString, pcFormatString);
            vsnprintf(acFormattedString, sizeof(acFormattedString),
                      pcFormatString, ParamListForString);
            va_end(ParamListForString);

            DebugPrintf("%s", acFormattedString);

            if (g_bLogToFile)
            {
                FILE *pLogFileStream = fopen(g_acLogFileFullPath, "a");

                if (pLogFileStream)
                {
                    fprintf(pLogFileStream, "%s", acFormattedString);

                    fclose(pLogFileStream);
                }
                else
                {
                    printf("Error %i opening log file: %s\n", errno, strerror(errno));
                }
            }
        }
    }
}

//=================================================================================================
bool FileExists(
    const char *pcFile
)
{
    bool bRetVal = False;

    ssize_t iFileSize;

    if (GetFileInfo(pcFile, &iFileSize) == 1)
    {
        bRetVal = True;
    }

    return bRetVal;
}

//=================================================================================================
const char *AddExtn(
    const char *pcAssemblyName,
    const char *pcExtension
)
{
    static char acCompleteNameBuffer[100];

    if (*pcExtension == '.')
    {
        pcExtension++;
    }

    snprintf(acCompleteNameBuffer, sizeof(acCompleteNameBuffer),
             "%s.%s", pcAssemblyName, pcExtension);

    return acCompleteNameBuffer;
}

//=================================================================================================
const char *PathCombine(
    const char *pcPathPart1,
    const char *pcPathPart2
)
{
    static char acCombinedPathBuffer[MAX_PATHNAME_LEN];

    int iPart1StrLen = snprintf(acCombinedPathBuffer, sizeof(acCombinedPathBuffer),
                                "%s", pcPathPart1);

    if (iPart1StrLen < (sizeof(acCombinedPathBuffer) - 1))
    {
        if (acCombinedPathBuffer[iPart1StrLen - 1] != '\\')
        {
            acCombinedPathBuffer[iPart1StrLen++] = '\\';
            acCombinedPathBuffer[iPart1StrLen] = '\0';
        }

        const char *pcPart2Start = pcPathPart2;
        if (*pcPart2Start == '\\')
        {
            pcPart2Start++;
        }

        snprintf(&(acCombinedPathBuffer[iPart1StrLen]),
                 (sizeof(acCombinedPathBuffer) - iPart1StrLen),
                 "%s", pcPart2Start);
    }

    return acCombinedPathBuffer;
}

