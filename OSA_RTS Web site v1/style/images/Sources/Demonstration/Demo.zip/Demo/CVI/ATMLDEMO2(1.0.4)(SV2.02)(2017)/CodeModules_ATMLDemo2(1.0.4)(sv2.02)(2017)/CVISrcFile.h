#include "tsutil.h"
#include "ATMLCVITypes.h"

void __declspec(dllexport) __stdcall  V_CC_to_GND_Resistance_Test(CAObjHandle sequenceContext,
				 const char *UUID, double *TestResult_V_CC_Resistance, long *errorOccurred,
				 long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  Apply_UUT_DC_Power(CAObjHandle sequenceContext,
				 const char *UUID, long *errorOccurred, long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  V_O_AC_Voltage_Test(CAObjHandle sequenceContext,
				 const char *UUID, double Parameter_V_I_Amplitude, double Parameter_V_I_Frequency,
				 double *TestResult_V_O_AC_Voltage, long *errorOccurred, long *errorCode,
				 char errorMsg[1024]);

void __declspec(dllexport) __stdcall  V_C_AC_Voltage_Test(CAObjHandle sequenceContext,
				 const char *UUID, double *TestResult_V_C_AC_Voltage, long *errorOccurred,
				 long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  V_C_DC_Voltage_Test(CAObjHandle sequenceContext,
				 const char *UUID, double *TestResult_V_C_DC_Voltage, long *errorOccurred,
				 long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  V_E_DC_Voltage_Test(CAObjHandle sequenceContext,
				 const char *UUID, double *TestResult_V_E_DC_Voltage, long *errorOccurred,
				 long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  V_B_DC_Voltage_Test(CAObjHandle sequenceContext,
				 const char *UUID, double *TestResult_V_B_DC_Voltage, long *errorOccurred,
				 long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  Gain_Control_Test(CAObjHandle sequenceContext,
				 const char *UUID, double Parameter_V_I_Amplitude, double Parameter_V_I_Frequency,
				 long Parameter_DigitalControl, double *TestResult_V_O_AC_Voltage,
				 long *errorOccurred, long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  Output_Control_Test(CAObjHandle sequenceContext,
				 const char *UUID, double Parameter_V_I_Amplitude, double Parameter_V_I_Frequency,
				 const char *Parameter_SerialCommand, double *TestResult_V_O_AC_Voltage,
				 long *errorOccurred, long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  CalculateGain(CAObjHandle sequenceContext,
				 const char *UUID, double *TestResult_Gain, long *PassFailResult,
				 long *errorOccurred, long *errorCode, char errorMsg[1024]);

void __declspec(dllexport) __stdcall  One_dB_CompressionPoint_Test_Repeat(CAObjHandle sequenceContext,
				 const char *UUID, double Parameter_V_I_Max_Power, double Parameter_V_I_Frequency,
				 double Parameter_Gain, long *TestResult_test12rGO, double *TestResult_test12rOutputPwr,
				 long *PassFailResult, long *errorOccurred, long *errorCode,
				 char errorMsg[1024]);

void __declspec(dllexport) __stdcall  One_dB_CompressionPoint_Test_Generic(CAObjHandle sequenceContext,
				 const char *UUID, double Parameter_Gain, double *TestResult_test13Res1,
				 long *PassFailResult, long *errorOccurred, long *errorCode,
				 char errorMsg[1024]);

void __declspec(dllexport) __stdcall  Remove_UUT_DC_Power(CAObjHandle sequenceContext,
				 const char *UUID, long *errorOccurred, long *errorCode, char errorMsg[1024]);

