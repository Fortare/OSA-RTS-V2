//=================================================================================================
//
// Title:         TestStnSpecificSupport.c
// Purpose:       Implements support functions specific to the test station.
//                There'll need to be a man-draulically generated one of these for each total
//                test station description.
//                Look for the TAILOR_THIS tags to find the bits that need customisation.
//                Customisations in here currently make it relevant to the Demo Version 6
//                test station.
//
// Created on:    22/05/2012 at 13:38:24 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/TestStnSpecificSupport.c $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 18/06/12 10:22 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

//=================================================================================================
// Include files

#define __TestStnSpecificSupport_C__

#include "Common.h"
#include "TestStnSpecificSupport.h"

//=================================================================================================
// Constants

// TAILOR_THIS
#define DEFAULT_ASSEMBLY_PATH "."

//=================================================================================================
// Global functions

void InitAssemblyInfo(
    const struct tAssemblyInfo ** const ppTypeAssemblyInfo,
    const struct tAssemblyInfo ** const ppImplementationAssemblyInfo
)
{
// TAILOR_THIS
    static const struct tAssemblyInfo TypeAssemblyInfo =
    {
        TYPE_ASSEMBLY_NAME,
        "1.0.0.0",
        "neutral",
        "null",
        DEFAULT_ASSEMBLY_PATH,
    };

// TAILOR_THIS
    static const struct tAssemblyInfo ImplementationAssemblyInfo =
    {
        IMPLEMENTATION_ASSEMBLY_NAME,
        "1.0.0.0",
        "neutral",
        "null",
        DEFAULT_ASSEMBLY_PATH,
    };

    *ppTypeAssemblyInfo           = &TypeAssemblyInfo;
    *ppImplementationAssemblyInfo = &ImplementationAssemblyInfo;
}
