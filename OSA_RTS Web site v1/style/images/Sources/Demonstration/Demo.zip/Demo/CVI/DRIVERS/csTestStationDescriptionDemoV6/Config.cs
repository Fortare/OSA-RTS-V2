﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               Config.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-Config-cs
//
// DESCRIPTION:        Implements the exposed public static object that can be used by clients to
//                     configure the implementation assembly.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/Config.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 15/06/12 18:28 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

namespace csTestStnDemoV6Imp
{
    public static class Config
    {
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Public Properties

        /// <summary>
        /// All trace output is sent to the file specified by this property, as well as being sent
        /// to stdout. Disabled by default by being set to an empty string.
        /// </summary>
        public static string LogFileFullPath { get; set; }

        /// <summary>
        /// Defines the prefix for error reports.
        /// </summary>
        public static String ErrorPrefix { get; set; }

        /// <summary>
        /// Enables method call trace.
        /// </summary>
        public static bool CallTraceEnable { get; set; }

        /// <summary>
        /// Defines the prefix for method call trace.
        /// </summary>
        public static String CallTracePrefix { get; set; }

        /// <summary>
        /// Enables IVI trace.
        /// </summary>
        public static bool IVITraceEnable { get; set; }

        /// <summary>
        /// Defines the prefix for IVI trace.
        /// </summary>
        public static String IVITracePrefix { get; set; }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        /// <summary>
        /// Constructor.
        /// </summary>
        static Config()
        {
            LogFileFullPath = "";

            ErrorPrefix = "!!! ";

            CallTraceEnable = true;
            CallTracePrefix = "++ ";

            IVITraceEnable = true;
            IVITracePrefix = "--- //IVI> ";
        }
    }
}
