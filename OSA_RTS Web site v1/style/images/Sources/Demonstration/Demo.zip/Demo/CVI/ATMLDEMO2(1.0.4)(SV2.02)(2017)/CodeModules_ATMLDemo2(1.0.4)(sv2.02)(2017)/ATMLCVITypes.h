typedef char NI_ATMLArrayIndexor[1024];
typedef char NI_ATMLComparisonOperator[1024];
typedef char NI_ATMLUuid[1024];
typedef char NI_ATMLNonBlankString[1024];
typedef char NI_ATMLStandardUnit[1024];
typedef char NI_ATMLEqualityComparisonOperator[1024];
typedef char NI_ATMLHexValue[1024];
typedef char NI_ATMLLogicalOperator[1024];
typedef char NI_ATMLMaskOperator[1024];
typedef char NI_ATMLNonBlankURI[1024];
typedef char NI_ATMLPortDirection[1024];
typedef char NI_ATMLPortType[1024];
struct NI_ATMLBinary
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char NI_ATMLValue[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLBinaryArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	char DefaultElementValue[1024];
	struct 
	{
		char NI_ATMLValue[1024];
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLBoolean
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		int NI_ATMLValue;
	} ATMLAttributes;

} ;

struct NI_ATMLBooleanArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLComplex
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		double Real;
		double Imaginary;
	} ATMLAttributes;

} ;

struct NI_ATMLComplexArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			double Real;
			double Imaginary;
		} ATMLAttributes;

	} DefaultElementValue;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			double Real;
			double Imaginary;
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLDateTime
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char NI_ATMLValue[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDateTimeArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
		} ATMLAttributes;

	} DefaultElementValue;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLDouble
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		double NI_ATMLValue;
	} ATMLAttributes;

} ;

struct NI_ATMLDoubleArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	double DefaultElementValue;
	struct 
	{
		double NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLHexadecimal
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char NI_ATMLValue[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLHexadecimalArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLInteger
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		int NI_ATMLValue;
	} ATMLAttributes;

} ;

struct NI_ATMLIntegerArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLOctal
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char NI_ATMLValue[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLOctalArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLString
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	char NI_ATMLValue[1024];
} ;

struct NI_ATMLStringArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	char DefaultElementValue[1024];
	struct 
	{
		char NI_ATMLValue[1024];
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLUnsignedInteger
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		unsigned int NI_ATMLValue;
	} ATMLAttributes;

} ;

struct NI_ATMLUnsignedIntegerArray
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	unsigned int DefaultElementValue;
	struct 
	{
		unsigned int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *Element;

} ;

struct NI_ATMLIdentificationNumber
{
	struct 
	{
		char Number[1024];
		char Type[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLMailingAddress
{
	char Address1[1024];
	char Address2[1024];
	char City[1024];
	char State[1024];
	char Country[1024];
	char PostalCode[1024];
} ;

struct NI_ATMLManufacturerData
{
	struct 
	{
		struct 
		{
			struct 
			{
				char Name[1024];
				char Email[1024];
				char PhoneNumber[1024];
			} ATMLAttributes;

		} *Contact;

	} Contacts;

	char FaxNumber[1024];
	struct 
	{
		char Address1[1024];
		char Address2[1024];
		char City[1024];
		char State[1024];
		char Country[1024];
		char PostalCode[1024];
	} MailingAddress;

	char URL[1024];
	struct 
	{
		char Name[1024];
		char CageCode[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLConnectorLocation
{
	struct 
	{
		char ConnectorID[1024];
		char PinID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDocumentReference
{
	struct 
	{
		char ID[1024];
		char Uuid[1024];
	} ATMLAttributes;

} ;

typedef char NI_ATMLErrorType[1024];
struct NI_ATMLVersionIdentifier
{
	struct 
	{
		char Name[1024];
		char Version[1024];
		char Qualifier[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLVPP
{
	struct 
	{
		char FileName[1024];
		char FilePath[1024];
		char Prefix[1024];
	} ATMLAttributes;

} ;

typedef char NI_ATMLTriggerPortType[1024];
struct NI_ATMLTriggerPort
{
	char Description[1024];
	struct 
	{
		char Name[1024];
		char Direction[1024];
		char Type[1024];
	} ATMLAttributes;

} ;

typedef char NI_ATMLLevelUnits[1024];
struct NI_ATMLLevelType
{
	struct 
	{
		double NI_ATMLValue;
		char Units[1024];
		int NumberOfBits;
	} ATMLAttributes;

} ;

typedef char NI_ATMLDigitalEdge[1024];
typedef char NI_ATMLDigitalLevel[1024];
struct NI_ATMLDetectionType
{
	struct 
	{
		char EdgeDetection[1024];
		char LevelDetection[1024];
	} ATMLAttributes;

} ;

typedef char NI_ATMLPulseUnits[1024];
struct NI_ATMLMinPulseWidthType
{
	struct 
	{
		double NI_ATMLValue;
		char Units[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSpecificationConditions
{
	char *Condition[1024];
} ;

typedef char NI_ATMLElectroOpticalInterfaceType[1024];
typedef char NI_ATMLSeverityLevel[1024];
typedef char NI_ATMLFailureType[1024];
typedef char NI_ATMLDetectability[1024];
typedef char NI_ATMLSignalType[1024];
typedef char NI_ATMLSignalRole[1024];
typedef char NI_ATMLSignalCharacteristicRole[1024];
typedef char NI_ATMLOutcomeValue[1024];
typedef char NI_ATMLComparisonResult[1024];
typedef char NI_ATMLTestType[1024];
struct NI_ATMLSignalInformation
{
	char SignalName[1024];
	char SignalType[1024];
	char SignalDefinition[1024];
} ;

struct NI_ATMLTsfClass
{
	struct 
	{
		char TsfLibraryID[1024];
		char TsfClassName[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLTsfClassAttributeName
{
	char NI_ATMLValue[1024];
} ;

struct NI_ATMLIeeeStd1641InValues
{
	struct 
	{
		struct 
		{
			char ParameterID[1024];
			char SignalName[1024];
			char SignalAttribute[1024];
		} ATMLAttributes;

	} *ParameterInValue;

	struct 
	{
		struct 
		{
			char IteratorID[1024];
			char SignalName[1024];
			char SignalAttribute[1024];
		} ATMLAttributes;

	} *IteratorInValue;

} ;

struct NI_ATMLDetectionIsolation
{
	struct 
	{
		struct 
		{
			struct 
			{
				char FaultID[1024];
			} ATMLAttributes;

		} *Fault;

	} Faults;

	struct 
	{
		struct 
		{
			struct 
			{
				char FailureID[1024];
			} ATMLAttributes;

		} *Failure;

	} Failures;

} ;

struct NI_ATMLOperationResetAll
{
	char Description[1024];
	struct 
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	char Timeout[1024];
} ;

struct NI_ATMLOperationDisable
{
	char Description[1024];
	struct 
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char LocalMonitorSignalID[1024];
		} ATMLAttributes;

	} LocalMonitorSignalReference;

	char Timeout[1024];
} ;

struct NI_ATMLOperationWaitFor
{
	char Description[1024];
	struct 
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	double TimeValue;
} ;

struct NI_ATMLOperationSetStateVariable
{
	char Description[1024];
	struct 
	{
		char ID[1024];
		char Name[1024];
		char StateVariableID[1024];
		char StateVariableValueID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLConnectionDatumDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	char NumberOfPorts[1024];
} ;

struct NI_ATMLValueFromTestGroupParameter
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char TestGroupParameterID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLValueFromActionParameter
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char ParameterID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLValueFromOperationMeasurement
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char MeasurementID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLValueFromOperationMessageIn
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char MessageInID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLValueFromIterator
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char IteratorID[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLBinaryDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	char NominalValue[1024];
} ;

struct NI_ATMLBinaryArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	char DefaultElementValue[1024];
	struct 
	{
		char NI_ATMLValue[1024];
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLBooleanDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	int NominalValue;
} ;

struct NI_ATMLBooleanArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLComplexDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			double Real;
			double Imaginary;
		} ATMLAttributes;

	} NominalValue;

} ;

struct NI_ATMLComplexArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			double Real;
			double Imaginary;
		} ATMLAttributes;

	} DefaultElementValue;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			double Real;
			double Imaginary;
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLDateTimeDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
		} ATMLAttributes;

	} NominalValue;

} ;

struct NI_ATMLDateTimeArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
		} ATMLAttributes;

	} DefaultElementValue;

	struct 
	{
		struct 
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLHexadecimalDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	int NominalValue;
} ;

struct NI_ATMLHexadecimalArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLDoubleDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	double NominalValue;
} ;

struct NI_ATMLDoubleArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	double DefaultElementValue;
	struct 
	{
		double NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLIntegerDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	int NominalValue;
} ;

struct NI_ATMLIntegerArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLOctalDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	int NominalValue;
} ;

struct NI_ATMLOctalArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	int DefaultElementValue;
	struct 
	{
		int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLStringDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	char NominalValue[1024];
} ;

struct NI_ATMLStringArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	char DefaultElementValue[1024];
	struct 
	{
		char NI_ATMLValue[1024];
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

struct NI_ATMLUnsignedIntegerDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

	unsigned int NominalValue;
} ;

struct NI_ATMLUnsignedIntegerArrayDescription
{
	struct 
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	unsigned int DefaultElementValue;
	struct 
	{
		unsigned int NI_ATMLValue;
		struct 
		{
			char Position[1024];
		} ATMLAttributes;

	} *NominalElementValue;

} ;

typedef char NI_ATMLQualifier[1024];
typedef char NI_ATMLQuantity[1024];
typedef char NI_ATMLErrlmt[1024];
typedef char NI_ATMLRange[1024];
typedef char NI_ATMLTo[1024];
typedef char *NI_ATML_physical[1024];
typedef char NI_ATML_expression[1024];
typedef char NI_ATMLPhysical[1024];
typedef char NI_ATMLAdmittance[1024];
typedef char NI_ATMLAmountOfInformation[1024];
typedef char NI_ATMLAmountOfSubstance[1024];
typedef char NI_ATMLCapacitance[1024];
typedef char NI_ATMLConductance[1024];
typedef char NI_ATMLCharge[1024];
typedef char NI_ATMLCurrent[1024];
typedef char NI_ATMLVoltage[1024];
typedef char NI_ATMLResistance[1024];
typedef char NI_ATMLEnergy[1024];
typedef char NI_ATMLForce[1024];
typedef char NI_ATMLFrequency[1024];
typedef char NI_ATMLHeat[1024];
typedef char NI_ATMLIlluminance[1024];
typedef char NI_ATMLImpedance[1024];
typedef char NI_ATMLInductance[1024];
typedef char NI_ATMLDistance[1024];
typedef char NI_ATMLLuminousFlux[1024];
typedef char NI_ATMLLuminousIntensity[1024];
typedef char NI_ATMLMagneticFlux[1024];
typedef char NI_ATMLMagneticFluxDensity[1024];
typedef char NI_ATMLMass[1024];
typedef char NI_ATMLPlaneAngle[1024];
typedef char NI_ATMLPower[1024];
typedef char NI_ATMLPressure[1024];
typedef char NI_ATMLRatio[1024];
typedef char NI_ATMLReactance[1024];
typedef char NI_ATMLSolidAngle[1024];
typedef char NI_ATMLSusceptance[1024];
typedef char NI_ATMLTemperature[1024];
typedef char NI_ATMLTime[1024];
typedef char NI_ATMLAcceleration[1024];
typedef char NI_ATMLAngularAcceleration[1024];
typedef char NI_ATMLAngularSpeed[1024];
typedef char NI_ATMLArea[1024];
typedef char NI_ATMLConcentration[1024];
typedef char NI_ATMLCurrentDensity[1024];
typedef char NI_ATMLDynamicViscosity[1024];
typedef char NI_ATMLElectricChargeDensity[1024];
typedef char NI_ATMLElectricFieldStrength[1024];
typedef char NI_ATMLElectricFluxDensity[1024];
typedef char NI_ATMLEnergyDensity[1024];
typedef char NI_ATMLEnthropy[1024];
typedef char NI_ATMLExposure[1024];
typedef char NI_ATMLHeatCapacity[1024];
typedef char NI_ATMLHeatFluxDensity[1024];
typedef char NI_ATMLIrradiance[1024];
typedef char NI_ATMLKinematicViscosity[1024];
typedef char NI_ATMLLuminance[1024];
typedef char NI_ATMLMagneticFieldStrength[1024];
typedef char NI_ATMLMassDensity[1024];
typedef char NI_ATMLMassFlow[1024];
typedef char NI_ATMLMolarEnergy[1024];
typedef char NI_ATMLMolarEntropy[1024];
typedef char NI_ATMLMolarHeatCapacity[1024];
typedef char NI_ATMLMomentOfForce[1024];
typedef char NI_ATMLMomentOfInertia[1024];
typedef char NI_ATMLMomentum[1024];
typedef char NI_ATMLPermeability[1024];
typedef char NI_ATMLPermittivity[1024];
typedef char NI_ATMLPowerDensity[1024];
typedef char NI_ATMLRadiance[1024];
typedef char NI_ATMLRadiantIntensity[1024];
typedef char NI_ATMLSpecificHeatCapacity[1024];
typedef char NI_ATMLSpecificEnergy[1024];
typedef char NI_ATMLSpecificEntropy[1024];
typedef char NI_ATMLSpecificVolume[1024];
typedef char NI_ATMLSurfaceTension[1024];
typedef char NI_ATMLThermalConductivity[1024];
typedef char NI_ATMLSpeed[1024];
typedef char NI_ATMLVolume[1024];
typedef char NI_ATMLVolumeFlow[1024];
typedef char NI_ATMLPulseDefn[1024];
typedef char *NI_ATMLPulseDefns[1024];
typedef char NI_ATMLEnumCondition[1024];
typedef char NI_ATMLEnumMeasuredVariable[1024];
typedef char NI_ATMLEnumPulseClass[1024];
typedef char NI_ATMLDigitalString[1024];
typedef char NI_ATMLPinString[1024];
typedef char *NI_ATMLList_Physical[1024];
typedef double *NI_ATMLList_double;
typedef char NI_ATMLInt[1024];
typedef char *NI_ATMLList_int[1024];
typedef char NI_ATMLLong[1024];
typedef char *NI_ATMLList_long[1024];
typedef char NI_ATMLAny[1024];
typedef char *NI_ATMLList_any[1024];
typedef char *NI_ATMLSAFEARRAY_BSTR[1024];
typedef char *NI_ATMLSAFEARRAY_Physical[1024];
typedef double *NI_ATMLSAFEARRAY_double;
typedef char *NI_ATMLSAFEARRAY_long[1024];
typedef char *NI_ATMLSAFEARRAY_VARIANT[1024];
typedef char *NI_ATMLList_string[1024];
typedef char NI_ATMLSignalID[1024];
typedef char NI_ATMLSignalREF[1024];
typedef char NI_ATMLSignalREFS[1024];
struct NI_ATMLSignalFunctionType
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLAC_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ac_ampl[1024];
		char Dc_offset[1024];
		char Freq[1024];
		char Phase[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLAM_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Mod_freq[1024];
		char Mod_depth[1024];
		char Mod_ampl[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDC_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Dc_ampl[1024];
		char Ac_ampl[1024];
		char Freq[1024];
		char Phase[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDIGITAL_PARALLEL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Data_value[1024];
		char Clock_period[1024];
		char Logic_one_value[1024];
		char Logic_zero_value[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDIGITAL_SERIAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Data_value[1024];
		char Clock_period[1024];
		char Logic_one_value[1024];
		char Logic_zero_value[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDME_INTERROGATION
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Int_freq[1024];
		char Int_rate[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDME_RESPONSE
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Resp_freq[1024];
		char Car_ampl[1024];
		char Range[1024];
		char Rate[1024];
		char Accn[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLFM_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Freq_dev[1024];
		char Mod_freq[1024];
		char Mod_ampl[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLILS_GLIDE_SLOPE
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Onefifty_level[1024];
		char Ninety_level[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLILS_LOCALIZER
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Onefifty_level[1024];
		char Ninety_level[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLILS_MARKER
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Marker_freq[1024];
		char Car_ampl[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLPM_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Phase_dev[1024];
		char Mod_freq[1024];
		char Mod_ampl[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLPULSED_AC_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ac_ampl[1024];
		char Freq[1024];
		char Dc_offset[1024];
		char P_delay[1024];
		char P_duration[1024];
		char Prf[1024];
		int P_repetition;
	} ATMLAttributes;

} ;

struct NI_ATMLPULSED_AC_TRAIN
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ac_ampl[1024];
		char Freq[1024];
		char Dc_offset[1024];
		char *Pulse_train[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLPULSED_DC_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Dc_ampl[1024];
		char Ac_ampl[1024];
		char Freq[1024];
		char P_delay[1024];
		char P_duration[1024];
		char Prf[1024];
		int P_repetition;
	} ATMLAttributes;

} ;

struct NI_ATMLPULSED_DC_TRAIN
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Dc_ampl[1024];
		char *Pulse_train[1024];
		char Ac_ampl[1024];
		char Freq[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLRADAR_RX_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Atten[1024];
		char Range[1024];
		char Range_accn[1024];
		char Range_rate[1024];
		char Reply_eff[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLRADAR_TX_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Freq[1024];
		char Delay[1024];
		char Duration[1024];
		char Prf[1024];
		int Repetition;
	} ATMLAttributes;

} ;

struct NI_ATMLRAMP_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Dc_offset[1024];
		char Period[1024];
		char Rise_time[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLRANDOM_NOISE
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Freq[1024];
		char Seed[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLRESOLVER
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Angle[1024];
		char Ampl[1024];
		char Freq[1024];
		char Zero_index[1024];
		char Angle_rate[1024];
		char Trans_ratio[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLRS_232
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Data_word[1024];
		char Baud_rate[1024];
		char Data_bits[1024];
		char Parity[1024];
		char Stop_bits[1024];
		char Flow_control[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSQUARE_WAVE
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Period[1024];
		char Dc_offset[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSSR_INTERROGATION
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Mode[1024];
		char P3_start[1024];
		char P3_level[1024];
		char Sls_dev[1024];
		char Sls_level[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSSR_RESPONSE
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char P3_start[1024];
		char *Pulses[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSTEP_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Dc_offset[1024];
		char Start_time[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSUP_CAR_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Mod_freq[1024];
		char Mod_depth[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLSYNCHRO
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Angle[1024];
		char Ampl[1024];
		char Freq[1024];
		char Zero_index[1024];
		char Angle_rate[1024];
		char Trans_ratio[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLTACAN
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Freq[1024];
		char Mod_index[1024];
		char Bearing[1024];
		char Car_ampl[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLTRIANGULAR_WAVE_SIGNAL
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Ampl[1024];
		char Period[1024];
		char Dc_offset[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLVOR
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Car_ampl[1024];
		char Car_freq[1024];
		char Phase[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLDIGITAL_TEST
{
	struct 
	{
		char Type[1024];
		char Reftype[1024];
		char Name[1024];
		char In[1024];
		char Channels[1024];
		char Gate[1024];
		char Sync[1024];
		char Conn[1024];
		char PinsIn[1024];
		char PinsOut[1024];
		char PinsSync[1024];
		char PinsGate[1024];
		char Dt__Period[1024];
		char Dt__Stim_H_value[1024];
		char Dt__Stim_L_value[1024];
		char Dt__Resp_L_value[1024];
		char Dt__Resp_H_value[1024];
		char Dt__Data[1024];
	} ATMLAttributes;

} ;

struct NI_ATMLFaultDictionary
{
	struct
	{
		struct
		{
			struct
			{
				struct
				{
					struct
					{
						char StepID[1024];
						char TestOutcomeID[1024];
					} ATMLAttributes;

				} *Result;

			} Results;

			struct
			{
				struct
				{
					char TestGroupOutcomeID[1024];
				} ATMLAttributes;

			} TestGroupOutcome;

			struct
			{
				char Name[1024];
			} ATMLAttributes;

		} *Rule;

	} Rules;

};

struct NI_ATMLOperationReadVariable
{
	char Description[1024];
	struct
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} ValueFrom;

	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} ValueTo;

};

struct NI_ATMLOperationDecodeMessage
{
	char Description[1024];
	struct
	{
		char ID[1024];
		char Name[1024];
		char MessageID[1024];
	} ATMLAttributes;

	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} ValueFrom;

	struct
	{
		struct
		{
			struct
			{
				struct
				{
					char Type[1024];
					char RefID[1024];
				} ATMLAttributes;

			} ValueTo;

			struct
			{
				char ParameterID[1024];
			} ATMLAttributes;

		} *OutValue;

	} OutValues;

};

struct NI_ATMLOperationFetch
{
	char Description[1024];
	struct
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} SignalRef;

	struct
	{
		struct
		{
			struct
			{
				struct
				{
					char Type[1024];
					char RefID[1024];
				} ATMLAttributes;

			} ValueTo;

			struct
			{
				char SignalName[1024];
				char SignalAttribute[1024];
				char MeasuredAttribute[1024];
			} ATMLAttributes;

		} *OutValue;

	} OutValues;

};

struct NI_ATMLOperationReset
{
	char Description[1024];
	struct
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	char Timeout[1024];
	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} SignalRef;

};

typedef char NI_ATMLBusItemTypes[1024];
struct NI_ATMLOperationWithTimeoutType
{
	char Description[1024];
	struct
	{
		char ID[1024];
		char Name[1024];
	} ATMLAttributes;

	char Timeout[1024];
};

struct NI_ATMLIeeeStd1641InValue
{
	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} ValueFrom;

	struct
	{
		char SignalName[1024];
		char SignalAttribute[1024];
	} ATMLAttributes;

};

struct NI_ATMLIeeeStd1641OutValue
{
	struct
	{
		struct
		{
			char Type[1024];
			char RefID[1024];
		} ATMLAttributes;

	} ValueTo;

	struct
	{
		char SignalName[1024];
		char SignalAttribute[1024];
		char MeasuredAttribute[1024];
	} ATMLAttributes;

};

typedef char NI_ATMLValueFromTypes[1024];
typedef char NI_ATMLValueToTypes[1024];
struct NI_ATMLValueFrom
{
	struct
	{
		char Type[1024];
		char RefID[1024];
	} ATMLAttributes;

};

struct NI_ATMLValueTo
{
	struct
	{
		char Type[1024];
		char RefID[1024];
	} ATMLAttributes;

};

struct NI_ATMLNullDatum
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

};

struct NI_ATMLSignalReference
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
	} ATMLAttributes;

};

struct NI_ATMLSignalArrayReference
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
		char ID[1024];
	} ATMLAttributes;

};

typedef char NI_ATMLNodeRole[1024];
typedef char NI_ATMLMessageLengthUnit[1024];
typedef char NI_ATMLOffsetReference[1024];
typedef char NI_ATMLBooleanEncoding[1024];
typedef char NI_ATMLIntegerEncoding[1024];
typedef char NI_ATMLFloatingPointEncoding[1024];
typedef char NI_ATMLStringEncoding[1024];
typedef char NI_ATMLCharacterEncoding[1024];
typedef char NI_ATMLFloatingPointNotation[1024];
typedef char NI_ATMLByteArrayEncoding[1024];
typedef char NI_ATMLUUTDocumentCategory[1024];

struct NI_ATMLDriverModule
{
	struct
	{
		char FileName[1024];
		char InstallationDirectory[1024];
	} ATMLAttributes;

};

struct NI_ATMLUserDefinedIdentificationNumber
{
	struct
	{
		char Number[1024];
		char Type[1024];
		char Qualifier[1024];
	} ATMLAttributes;

};

struct NI_ATMLManufacturerIdentificationNumber
{
	struct
	{
		char Number[1024];
		char Type[1024];
		char ManufacturerName[1024];
	} ATMLAttributes;

};

struct NI_ATMLUnsignedLong
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char NI_ATMLValue[1024];
	} ATMLAttributes;

};

struct NI_ATMLUnsignedLongArray
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	struct
	{
		struct
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
		} ATMLAttributes;

	} DefaultElementValue;

	struct
	{
		struct
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
			char Position[1024];
		} ATMLAttributes;

	} *Element;

};

struct NI_ATMLLong
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char NI_ATMLValue[1024];
	} ATMLAttributes;

};

struct NI_ATMLLongArray
{
	struct
	{
		char StandardUnit[1024];
		char NonStandardUnit[1024];
		char UnitQualifier[1024];
		char Dimensions[1024];
	} ATMLAttributes;

	struct
	{
		struct
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
		} ATMLAttributes;

	} DefaultElementValue;

	struct
	{
		struct
		{
			char StandardUnit[1024];
			char NonStandardUnit[1024];
			char UnitQualifier[1024];
			char NI_ATMLValue[1024];
			char Position[1024];
		} ATMLAttributes;

	} *Element;

};