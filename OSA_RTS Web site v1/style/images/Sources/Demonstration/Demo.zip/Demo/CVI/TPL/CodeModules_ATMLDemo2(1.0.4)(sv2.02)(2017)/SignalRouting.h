//*************************************************************************************************
//  Cassidian TES Ltd
//  � Crown Copyright 2012
//                                                                  
//  NAME:               SignalRouting.h
//                                                                      
//  SOFTWARE NUMBER:    111104/SW/OSA_RTS-SignalRouting-h
//                                                                      
//  DESCRIPTION:        Provides the functions, types and variables definitions required for the 
//                      SignalRouteing Module
//                                                                      
//  This is a controlled document. See project configuration
//  control tool for latest version and full version history.
//                                                                      
//  SCC Database:   $Archive: /OSA RTS/Demo/CVI/TPL/CodeModules_ATMLDemo2(1.0.4)(sv2.02)(2017)/SignalRouting.h $
//  File Version:   $Revision: 1 $
//  Last Modified:  $Modtime: 13/11/20 13:02 $
//  By Author:      $Author: Knash $
//
//  $NoKeywords: $
//
//*************************************************************************************************

#ifndef __SignalRouting_H__
#define __SignalRouting_H__

#ifdef __cplusplus
    extern "C" {
#endif

//=================================================================================================
// Include files

#include <stdtst.h>
#include <ivi.h>

//=================================================================================================
// Global functions

void DLLEXPORT SetRemotingUri(CAObjHandle seqContextCVI);

// IviSwtch_reset
ViStatus DLLEXPORT _VI_FUNC IviSwtch_reset(ViSession vi);

// Switch Routing Functions
//ViStatus DLLEXPORT _VI_FUNC IviSwtch_Connect(ViSession vi, ViConstString channel1, ViConstString channel2);
ViStatus DLLEXPORT _VI_FUNC IviSwtch_Connect(ViSession vi, ViConstString channel1, ViConstString channel2, ViConstString signal);
//ViStatus DLLEXPORT _VI_FUNC IviSwtch_Disconnect(ViSession vi, ViConstString channel1,ViConstString channel2);
ViStatus DLLEXPORT _VI_FUNC IviSwtch_Disconnect(ViSession vi, ViConstString channel1,ViConstString channel2, ViConstString signal);
ViStatus DLLEXPORT _VI_FUNC IviSwtch_DisconnectAll(ViSession vi);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __SignalRouting_H__ */
