//=================================================================================================
//
// Title:         Utils.h
// Purpose:       Declares useful general purpose utility functions.
//
// Created on:    22/05/2012 at 12:59:27 by eads.
// Copyright:     � Crown Copyright 2012. All Rights Reserved.
//
// SCC Database:  $Archive: /OSA RTS/Demo/CVI/DRIVERS/CVIRuntimeSupport/Utils.h $
// File Version:  $Revision: 1 $
// Last Modified: $Modtime: 6/07/12 9:51 $
// By Author:     $Author: Knash $
//
// $NoKeywords: $
//
//=================================================================================================

#ifndef __Utils_H__
#define __Utils_H__

//=================================================================================================
// Include files

#include <utility.h>   // For MAX_PATHNAME_LEN

#include "Common.h"    // For bool

#ifdef __cplusplus
    extern "C" {
#endif

//=================================================================================================
// Constants

// Use one of these for first parameter to trace():
#define TRACE_OFF   0
#define TRACE_BASIC 1
#define TRACE_FULL  2
#define TRACE_ALWAYS (TRACE_OFF - 1)

//=================================================================================================
// Variables

#ifdef __Utils_C__
bool g_bLogToFile = False;
char g_acLogFileFullPath[MAX_PATHNAME_LEN] = "";
#else
extern bool g_bLogToFile;
extern char g_acLogFileFullPath[MAX_PATHNAME_LEN];
#endif

//==============================================================================
// Global functions

void trace(
    int         iMessageLevel,
    const char *pcFormatString,
    ...
);

bool FileExists(
    const char *pcFile
);

const char *AddExtn(
    const char *pcAssemblyName,
    const char *pcExtension
);

const char *PathCombine(
    const char *pcPathPart1,
    const char *pcPathPart2
);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __Utils_H__ */
