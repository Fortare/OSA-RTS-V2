﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               Signal.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-Signal-cs
//
// DESCRIPTION:        Implements the ISignal interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/Signal.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 18/06/12 15:00 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using ISignal = TestStationDescriptionDemoV6.ISignal;
using ISignalFunction = TestStationDescriptionDemoV6.ISignalFunction;
using _SIGNAL_STATE = TestStationDescriptionDemoV6._SIGNAL_STATE;

namespace csTestStnDemoV6Imp
{
    internal class SignalDCWithDCPS1_outSignal : Signal
    {
        public SignalDCWithDCPS1_outSignal()
        {
            m_sRunFmt = "IviDCPwr_ConfigureOutputEnabled(m_dcps, dcpsChName, VI_TRUE);\r\n" +
                        "Delay(2.0); // Allow firmware to set gain to max.";

            m_sStopFmt = "IviDCPwr_ConfigureOutputEnabled(m_dcps, dcpsChName, VI_FALSE);";
        }
    }

    internal class Signal : ISignal
    {
        protected String m_sRunFmt = "";
        protected String m_sStopFmt = "";
        protected String m_sChangeFmt = "";

        #region ISignal Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        public ISignalFunction SignalFunction
        {
            get { throw new NotImplementedException(); }
        }

        public _SIGNAL_STATE state
        {
            get { throw new NotImplementedException(); }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public void Change(int timeOut)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "Signal.Change(" + timeOut.ToString() + ")");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sChangeFmt, timeOut);
        }

        public System.Collections.IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public void Run(int timeOut)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "Signal.Run(" + timeOut.ToString() + ")");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sRunFmt, timeOut);
        }

        public void Stop(int timeOut)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "Signal.Stop(" + timeOut.ToString() + ")");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sStopFmt, timeOut);
        }

        #endregion
    }
}
