﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               Physical.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-Physical-cs
//
// DESCRIPTION:        Implements the IPhysical interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/Physical.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 22/11/20 18:02 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;
using System.Globalization;
using System.Text.RegularExpressions;
using nWXPhysical;

using IPhysical = TestStationDescriptionDemoV6.IPhysical;
using IQuantity = TestStationDescriptionDemoV6.IQuantity;
using _QUALIFIER_TYPE = TestStationDescriptionDemoV6._QUALIFIER_TYPE;
using _ERRLMT_TYPE = TestStationDescriptionDemoV6._ERRLMT_TYPE;
using _RANGE_TYPE = TestStationDescriptionDemoV6._RANGE_TYPE;

namespace csTestStnDemoV6Imp
{
    internal class Physical_MeasureResistanceWithDMM1_nominal : Physical
    {
        public Physical_MeasureResistanceWithDMM1_nominal()
        {
            // For simplicity assume assigned value will always be in kOhms.
            m_sValueSetterFmt = "IviDmm_SetAttributeViReal64(m_dmm, VI_NULL, IVIDMM_ATTR_RANGE, 10 * {0} * 1000);";
        }
    }

    internal class Physical_MeasureResistanceWithDMM1_measurement : Physical
    {
        public Physical_MeasureResistanceWithDMM1_measurement()
        {
            m_sValueMagnitudeGetterFmt = "IviDmm_Read(m_dmm, 1000, &value);";
        }
    }

    internal class Physical_DCWithDCPS1_dc_ampl : Physical
    {
        public Physical_DCWithDCPS1_dc_ampl()
        {
            m_sValueSetterFmt = "IviDCPwr_SetAttributeViReal64(m_dcps, dcpsChName, IVIDCPWR_ATTR_CURRENT_LIMIT, current);\r\n" +
                                "IviDCPwr_SetAttributeViInt32(m_dcps, dcpsChName, IVIDCPWR_ATTR_CURRENT_LIMIT_BEHAVIOR, IVIDCPWR_VAL_CURRENT_REGULATE);\r\n" +
                                "IviDCPwr_SetAttributeViReal64(m_dcps, dcpsChName, IVIDCPWR_ATTR_VOLTAGE_LEVEL, {0});";
        }
    }

    internal class Physical_DCVoltageWithDMM1_dc_range : Physical
    {
        public Physical_DCVoltageWithDMM1_dc_range()
        {
            m_sValueSetterFmt = "IviDmm_SetAttributeViReal64(m_dmm, VI_NULL, IVIDMM_ATTR_RANGE, 15.0);";
        }
    }

    internal class Physical_DCVoltageWithDMM1_measurement : Physical
    {
        public Physical_DCVoltageWithDMM1_measurement()
        {
            m_sValueMagnitudeGetterFmt = "IviDmm_Read(m_dmm, 1000, &value);";
        }
    }

    internal class Physical : IPhysical
    {
        protected String m_sValueSetterFmt = "";
        protected bool m_bStripUnitsOnValueSet = true;
        protected String m_sValueMagnitudeGetterFmt = "";

        private string m_sValue;
        private double m_dMagnitude;

        public Physical()
        {
            m_sValue = "42";
            SetMagnitudeFromValue();
        }

        private void SetMagnitudeFromValue()
        {
            //String sUnitless = Regex.Replace(m_sValue, "[ _a-zA-Z]*$", "", RegexOptions.RightToLeft);
            nWXPhysical.nWXPhysical phyFactory = new nWXPhysical.nWXPhysical();
            nWXPhysical.Physical phy = phyFactory.CreatePhysical("Physical");

            try
            {
                phy.value = m_sValue;
                //m_dMagnitude = double.Parse(sUnitless, NumberStyles.Any);
            }
            catch (Exception exception)
            {
                Reporter.Report(etMsgType.eMT_Error, "double.Parse() exception: " + exception.Message);
            }
//			m_dMagnitude = phy.magnitude;
			String sUnitless = Regex.Replace(m_sValue, "[ _a-zA-Z]*$", "", RegexOptions.RightToLeft);
			m_dMagnitude = double.Parse(sUnitless, NumberStyles.Any);
       }

        #region IPhysical Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        public IQuantity confidence
        {
            get { throw new NotImplementedException(); }
        }

        public IQuantity load_
        {
            get { throw new NotImplementedException(); }
        }

        public double magnitude
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying Physical.magnitude.");
                Reporter.Report(etMsgType.eMT_IVITrace, m_sValueMagnitudeGetterFmt, m_dMagnitude);
                return m_dMagnitude;
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public _QUALIFIER_TYPE qualifier
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IQuantity resolution
        {
            get { throw new NotImplementedException(); }
        }

        public string unit
        {
            get { throw new NotImplementedException(); }
        }

        public object value
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying Physical.value.");
                Reporter.Report(etMsgType.eMT_IVITrace, m_sValueMagnitudeGetterFmt, m_sValue);

                return m_sValue;
            }
            set
            {
                if (value.GetType() == typeof(string))
                {
                    Reporter.Report(etMsgType.eMT_CallTrace, "Physical.value = \"" + value + "\"");

                    m_sValue = value.ToString();
                    SetMagnitudeFromValue();

                    // TODO. Possibly. Parse m_sValue in order to set other
                    // dependent properties.

                    Reporter.Report(etMsgType.eMT_IVITrace, m_sValueSetterFmt,
                                    (m_bStripUnitsOnValueSet ? m_dMagnitude.ToString() : m_sValue));
                }
                else
                {
                    throw new NotImplementedException();
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public IQuantity get_errlmt(_ERRLMT_TYPE index)
        {
            throw new NotImplementedException();
        }

        public IQuantity get_range(_RANGE_TYPE index)
        {
            throw new NotImplementedException();
        }

        public IQuantity get_withUnit(string unit)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
