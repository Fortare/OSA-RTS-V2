﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               ACSignal.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-ACSignal-cs
//
// DESCRIPTION:        Implements the IACSignal interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/ACSignal.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 16/06/12 22:44 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using IACSignal = TestStationDescriptionDemoV6.IACSignal;
using ISignal = TestStationDescriptionDemoV6.ISignal;
using ISFCollection = TestStationDescriptionDemoV6.ISFCollection;
using IPhysical = TestStationDescriptionDemoV6.IPhysical;

namespace csTestStnDemoV6Imp
{
    internal class ACSignalWithAWG1 : ACSignal
    {
        public ACSignalWithAWG1()
        {
            m_sUniqueId = "AWG1";

            Reporter.Report(etMsgType.eMT_IVITrace, "");

            m_sCleanup = "";

            m_amplitude = new Physical();
            m_frequency = new Physical();

            m_outSignal = new Signal();
        }
    }

    public abstract class ACSignal : IACSignal, IDisposable
    {
        protected String m_sUniqueId = "Unset";

        protected String m_sCleanup = "";

        protected IPhysical m_amplitude;
        protected IPhysical m_frequency;

        protected ISignal m_outSignal;

        #region IACSignal Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Properties

        public ISignal Gate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public ISFCollection SignalFunctions
        {
            get { throw new NotImplementedException(); }
        }

        public ISignal Sync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IPhysical amplitude
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ACSignal.amplitude.");
                return m_amplitude;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ACSignal.amplitude = " + value.ToString());
                m_amplitude.value = value.value;
            }
        }

        public IPhysical frequency
        {
            get
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "Supplying ACSignal.frequency.");
                return m_frequency;
            }
            set
            {
                Reporter.Report(etMsgType.eMT_CallTrace, "ACSignal.frequency = " + value.ToString());
                m_frequency.value = value.value;
            }
        }

        public string name
        {
            get { throw new NotImplementedException(); }
        }

        public string pinsGate
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsIn
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsOut
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string pinsSync
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public ISignal get_Conn(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_In(int at)
        {
            throw new NotImplementedException();
        }

        public ISignal get_Out(int at)
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "ACSignal.get_Out(" + at.ToString() + ")");
            return m_outSignal;
        }

        public object get_attribute(string name)
        {
            throw new NotImplementedException();
        }

        public void set_Conn(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        public void set_In(int at, ISignal pVal)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Reporter.Report(etMsgType.eMT_CallTrace, "ACSignal.Dispose()");
            Reporter.Report(etMsgType.eMT_IVITrace, m_sCleanup);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
