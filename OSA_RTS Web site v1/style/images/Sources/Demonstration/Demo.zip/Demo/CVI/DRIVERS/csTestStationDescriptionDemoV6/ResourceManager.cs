﻿//*************************************************************************************************
// Cassidian TES Ltd
// © Crown Copyright 2012
//
// NAME:               ResourceManager.cs
//
// SOFTWARE NUMBER:    111104/SW/OSA_RTS-RuntimeImplementations-Demo6Stn-ResourceManager-cs
//
// DESCRIPTION:        Implements the IResourceManager interface defined in
//                     TestStationDescriptionDemoV6.
//
// This is a controlled document. See project configuration
// control tool for latest version and full version history.
//
// SCC Database:   $Archive: /OSA RTS/Demo/CVI/DRIVERS/csTestStationDescriptionDemoV6/ResourceManager.cs $
// File Version:   $Revision: 1 $
// Last Modified:  $Modtime: 16/06/12 23:31 $
// By Author:      $Author: Knash $
//
// $NoKeywords: $
//
//*************************************************************************************************
using System;

using IResourceManager = TestStationDescriptionDemoV6.IResourceManager;
using ISignalFunction = TestStationDescriptionDemoV6.ISignalFunction;

namespace csTestStnDemoV6Imp
{
    public class ResourceManager : IResourceManager
    {
        #region IResourceManager Members

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Methods

        public ISignalFunction Require(string SignalDescriptor, object UniqueId)
        {
            String sUniqueId = UniqueId.ToString();

            Reporter.Report(etMsgType.eMT_CallTrace, "ResourceManager.Require(\"" + SignalDescriptor +
                                                     "\", \"" + sUniqueId + "\")");
            switch (SignalDescriptor)
            {
                case "MeasureResistance":
                    switch (sUniqueId)
                    {
                        case "DMM1":
                            return new MeasureResistanceWithDMM1();
                        default:
                            throw new NotImplementedException();
                    }
                case "DC":
                    switch (sUniqueId)
                    {
                        case "DCPS1":
                            return new DCWithDCPS1();
                        default:
                            throw new NotImplementedException();
                    }
                case "ACSignal":
                    switch (sUniqueId)
                    {
                        case "AWG1":
                            return new ACSignalWithAWG1();
                        default:
                            throw new NotImplementedException();
                    }
                case "ACMeasure":
                    switch (sUniqueId)
                    {
                        case "DMM1":
                            return new ACMeasureWithDMM1();
                        default:
                            throw new NotImplementedException();
                    }
                case "DCVoltage":
                    switch (sUniqueId)
                    {
                        case "DMM1":
                            return new DCVoltageWithDMM1();
                        default:
                            throw new NotImplementedException();
                    }
                case "ONE_DB_COMPRESSION_POINT":
                    switch (sUniqueId)
                    {
                        case "ZVB8":
                            return new ONE_DB_COMPRESSION_POINTWithZVB8();
                        default:
                            throw new NotImplementedException();
                    }
                default:
                    throw new NotImplementedException();
            }
        }

        #endregion
    }
}
