

void Operation_Connect(const char* operationID, const char* signalID, char* errMsg);

double Operation_Read(const char* operationID, const char* signalID, const char* measurementID, char* errMsg);

void Operation_Disconnect(const char* operationID, const char* signalID, char* errMsg);
